from __future__ import annotations

import os
import time
from dataclasses import asdict
from pathlib import Path
from typing import Optional, Any

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QTabWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox,
    QCheckBox, QTextEdit, QFileDialog, QGroupBox, QProgressBar, QStatusBar
)

from ptmod.config import SongConfig
from ptmod.engines.playback_engine import PlaybackEngine
from ptmod.engines.sample_engine import SampleEngine, SamplePreviewSpec
from ptmod.engines.pattern_engine import format_pattern, order_positions_for_pattern
from ptmod.engines.generator_engine import generate_with_ralph_loop

import protracker_mod_choral_generator as backend


class GenerationWorker(QThread):
    status = pyqtSignal(str)
    progress = pyqtSignal(int)
    log = pyqtSignal(str)
    finished = pyqtSignal(object, object, object)   # (Path, SongData, QualityResult|None)
    rendered = pyqtSignal(bytes)                    # preview wav bytes (stereo)

    def __init__(self, cfg: SongConfig):
        super().__init__()
        self.cfg = cfg
        self._preview_rate = 44100

    def run(self):
        try:
            self.status.emit("thinking...")
            self.progress.emit(1)

            def _st(s: str):
                # Avoid empty status holes
                self.status.emit(s if (s and s.strip()) else "thinking...")

            def _pr(p: int):
                self.progress.emit(int(max(0, min(100, p))))

            def _lg(s: str):
                self.log.emit(str(s))

            mod_path, song, q = generate_with_ralph_loop(self.cfg, status_cb=_st, progress_cb=_pr, log_cb=_lg)
            self.finished.emit(mod_path, song, q)

            # Render preview WAV for playback
            self.status.emit("thinking...")
            self.progress.emit(0)

            def _render_prog(done: int, total: int):
                pct = 0.0 if total <= 0 else (done / float(total)) * 100.0
                self.status.emit(f"render {pct:.0f}%")
                self.progress.emit(int(pct))

            pcm16, sr, _chbufs = backend.render_song_to_pcm16(song, out_rate=self._preview_rate, progress_cb=_render_prog, cancel_event=None)
            wavb = backend.pcm16_to_wav_bytes(pcm16, sr, nch=2)

            self.rendered.emit(wavb)
            self.status.emit("ready")
            self.progress.emit(100)

        except Exception as e:
            self.log.emit(f"[error] {e}")
            self.status.emit("ready")
            self.progress.emit(0)


class MainWindow(QMainWindow):
    def __init__(self, themes: dict, apply_theme_cb):
        super().__init__()
        self.setWindowTitle("ProTracker MOD Generator — PyQt6 UI")
        self.resize(1100, 780)

        self.themes = themes
        self.apply_theme_cb = apply_theme_cb

        self.cfg = SongConfig()
        self.last_song: Optional[Any] = None
        self.last_mod_path: Optional[Path] = None
        self.last_quality: Optional[Any] = None
        self.preview_wav: Optional[bytes] = None

        self.playback = PlaybackEngine()
        self.sample_engine = SampleEngine()

        self._build_ui()

    # ---------- UI ----------
    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        root_layout = QVBoxLayout(root)

        self.tabs = QTabWidget()
        root_layout.addWidget(self.tabs)

        self._tab_generate()
        self._tab_options()
        self._tab_samples()
        self._tab_patterns()
        self._tab_log()

        # Status bar
        sb = QStatusBar()
        self.setStatusBar(sb)
        self.status_label = QLabel("ready")
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedWidth(220)
        sb.addWidget(self.status_label, 1)
        sb.addPermanentWidget(self.progress_bar)

    def _tab_generate(self):
        w = QWidget()
        self.tabs.addTab(w, "Generate")
        layout = QVBoxLayout(w)

        # --- song parameters ---
        grp = QGroupBox("Song Parameters")
        g = QGridLayout(grp)

        # out dir
        g.addWidget(QLabel("Output dir"), 0, 0)
        self.out_dir = QLineEdit(self.cfg.out_dir)
        btn_browse = QPushButton("Browse…")
        btn_browse.clicked.connect(self._browse_out_dir)
        g.addWidget(self.out_dir, 0, 1)
        g.addWidget(btn_browse, 0, 2)

        # seed
        g.addWidget(QLabel("Seed"), 1, 0)
        self.seed = QLineEdit("")
        btn_seed = QPushButton("Random")
        btn_seed.clicked.connect(self._random_seed)
        g.addWidget(self.seed, 1, 1)
        g.addWidget(btn_seed, 1, 2)

        # speed / tempo
        g.addWidget(QLabel("Speed"), 2, 0)
        self.speed = QSpinBox(); self.speed.setRange(1, 31); self.speed.setValue(self.cfg.speed)
        g.addWidget(self.speed, 2, 1)

        g.addWidget(QLabel("Tempo"), 2, 2)
        self.tempo = QSpinBox(); self.tempo.setRange(32, 255); self.tempo.setValue(self.cfg.tempo)
        g.addWidget(self.tempo, 2, 3)

        # key root
        g.addWidget(QLabel("Key root"), 3, 0)
        self.key_root = QComboBox()
        self.key_root.addItem("Random")
        for n in backend.CHROMATIC:
            self.key_root.addItem(n)
        g.addWidget(self.key_root, 3, 1)

        # scale mode
        g.addWidget(QLabel("Scale/mode"), 3, 2)
        self.scale_mode = QComboBox()
        for s in backend.SCALE_MODE_CHOICES:
            self.scale_mode.addItem(s)
        self.scale_mode.setCurrentText(self.cfg.scale_mode)
        g.addWidget(self.scale_mode, 3, 3)

        # variation
        g.addWidget(QLabel("Variation"), 4, 0)
        self.variation = QDoubleSpinBox()
        self.variation.setRange(0.0, 1.5)
        self.variation.setSingleStep(0.05)
        self.variation.setValue(self.cfg.variation)
        g.addWidget(self.variation, 4, 1)

        # stereo
        g.addWidget(QLabel("Stereo width"), 4, 2)
        self.stereo = QDoubleSpinBox()
        self.stereo.setRange(0.0, 2.0)
        self.stereo.setSingleStep(0.05)
        self.stereo.setValue(self.cfg.stereo_width)
        g.addWidget(self.stereo, 4, 3)

        # melody
        g.addWidget(QLabel("Melody preset"), 5, 0)
        self.melody = QComboBox()
        for m in backend.MELODY_CHOICES:
            self.melody.addItem(m)
        g.addWidget(self.melody, 5, 1)

        # derive
        g.addWidget(QLabel("Derive"), 5, 2)
        self.derive = QComboBox()
        for d in ["Random", "Near", "Far"]:
            self.derive.addItem(d)
        g.addWidget(self.derive, 5, 3)

        layout.addWidget(grp)

        # --- instruments ---
        grp2 = QGroupBox("Instruments (Channels 1–4)")
        g2 = QGridLayout(grp2)

        self.inst = []
        for ch in range(4):
            g2.addWidget(QLabel(f"CH{ch+1}"), ch, 0)
            cb = QComboBox()
            for x in backend.INSTRUMENT_CHOICES:
                cb.addItem(x)
            cb.setCurrentText(self.cfg.instruments[ch])
            self.inst.append(cb)
            g2.addWidget(cb, ch, 1)

        layout.addWidget(grp2)

        # --- action buttons ---
        row = QHBoxLayout()
        self.btn_generate = QPushButton("Generate MOD")
        self.btn_generate.clicked.connect(self._start_generation)

        self.btn_play_song = QPushButton("Play Preview")
        self.btn_play_song.clicked.connect(self._play_preview)
        self.btn_play_song.setEnabled(False)

        self.btn_stop = QPushButton("Stop")
        self.btn_stop.clicked.connect(self._stop_playback)
        self.btn_stop.setEnabled(True)

        row.addWidget(self.btn_generate)
        row.addWidget(self.btn_play_song)
        row.addWidget(self.btn_stop)
        row.addStretch(1)

        layout.addLayout(row)

        self.gen_result = QLabel("—")
        self.gen_result.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.gen_result)

    def _tab_options(self):
        w = QWidget()
        self.tabs.addTab(w, "Options")
        layout = QVBoxLayout(w)

        grp = QGroupBox("Generation Options")
        g = QGridLayout(grp)

        self.chk_slowdown = QCheckBox("Enable slowdown at end")
        self.chk_slowdown.setChecked(self.cfg.enable_slowdown)
        g.addWidget(self.chk_slowdown, 0, 0, 1, 2)

        self.chk_vibrato = QCheckBox("Disable vibrato in samples")
        self.chk_vibrato.setChecked(self.cfg.disable_vibrato)
        g.addWidget(self.chk_vibrato, 1, 0, 1, 2)

        self.chk_fadeout = QCheckBox("Add empty fade-out pattern")
        self.chk_fadeout.setChecked(self.cfg.fadeout_pattern)
        g.addWidget(self.chk_fadeout, 2, 0, 1, 2)

        self.chk_compat = QCheckBox("Compatibility safeguards (recommended)")
        self.chk_compat.setChecked(self.cfg.compat_mode)
        g.addWidget(self.chk_compat, 3, 0, 1, 2)

        layout.addWidget(grp)

        grp2 = QGroupBox("Ralph-Loop (quality retry loop)")
        g2 = QGridLayout(grp2)

        self.chk_ralph = QCheckBox("Enable Ralph-Loop")
        self.chk_ralph.setChecked(self.cfg.ralph_loop)
        g2.addWidget(self.chk_ralph, 0, 0, 1, 2)

        g2.addWidget(QLabel("Target score (%)"), 1, 0)
        self.ralph_target = QDoubleSpinBox()
        self.ralph_target.setRange(0.0, 100.0)
        self.ralph_target.setValue(self.cfg.ralph_target_score)
        g2.addWidget(self.ralph_target, 1, 1)

        g2.addWidget(QLabel("Max attempts"), 2, 0)
        self.ralph_attempts = QSpinBox()
        self.ralph_attempts.setRange(1, 250)
        self.ralph_attempts.setValue(self.cfg.ralph_max_attempts)
        g2.addWidget(self.ralph_attempts, 2, 1)

        layout.addWidget(grp2)

        grp3 = QGroupBox("Theme")
        g3 = QGridLayout(grp3)

        g3.addWidget(QLabel("Theme"), 0, 0)
        self.theme_combo = QComboBox()
        for name in self.themes.keys():
            self.theme_combo.addItem(name)
        self.theme_combo.setCurrentText("Modern Dark" if "Modern Dark" in self.themes else self.theme_combo.currentText())
        btn_apply = QPushButton("Apply")
        btn_apply.clicked.connect(self._apply_theme)
        g3.addWidget(self.theme_combo, 0, 1)
        g3.addWidget(btn_apply, 0, 2)

        layout.addWidget(grp3)
        layout.addStretch(1)

    def _tab_samples(self):
        w = QWidget()
        self.tabs.addTab(w, "Samples")
        layout = QVBoxLayout(w)

        info = QLabel("Samples are always previewable. If no custom WAV is set, the app synthesizes a short preview from the selected instrument.")
        info.setWordWrap(True)
        layout.addWidget(info)

        grp = QGroupBox("Channel Samples")
        g = QGridLayout(grp)

        self.sample_path_labels = []
        for ch in range(4):
            g.addWidget(QLabel(f"CH{ch+1}"), ch, 0)

            path_lbl = QLabel("Generated")
            path_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.sample_path_labels.append(path_lbl)
            g.addWidget(path_lbl, ch, 1)

            btn_import = QPushButton("Import WAV…")
            btn_import.clicked.connect(lambda _=False, c=ch: self._import_sample(c))
            g.addWidget(btn_import, ch, 2)

            btn_reset = QPushButton("Reset")
            btn_reset.clicked.connect(lambda _=False, c=ch: self._reset_sample(c))
            g.addWidget(btn_reset, ch, 3)

            btn_play = QPushButton("Play")
            btn_play.clicked.connect(lambda _=False, c=ch: self._play_sample(c))
            g.addWidget(btn_play, ch, 4)

        layout.addWidget(grp)
        layout.addStretch(1)

    def _tab_patterns(self):
        w = QWidget()
        self.tabs.addTab(w, "Patterns")
        layout = QVBoxLayout(w)

        top = QHBoxLayout()
        top.addWidget(QLabel("Pattern"))
        self.pattern_sel = QComboBox()
        self.pattern_sel.currentIndexChanged.connect(self._update_pattern_preview)
        top.addWidget(self.pattern_sel, 1)

        btn_refresh = QPushButton("Refresh")
        btn_refresh.clicked.connect(self._refresh_patterns)
        top.addWidget(btn_refresh)

        layout.addLayout(top)

        self.pattern_view = QTextEdit()
        self.pattern_view.setReadOnly(True)
        self.pattern_view.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        layout.addWidget(self.pattern_view, 1)

        self.pattern_hint = QLabel("Generate a song to see patterns here.")
        self.pattern_hint.setWordWrap(True)
        layout.addWidget(self.pattern_hint)

    def _tab_log(self):
        w = QWidget()
        self.tabs.addTab(w, "Log")
        layout = QVBoxLayout(w)
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        layout.addWidget(self.log_view)

        row = QHBoxLayout()
        btn_clear = QPushButton("Clear log")
        btn_clear.clicked.connect(lambda: self.log_view.setPlainText(""))
        row.addWidget(btn_clear)
        row.addStretch(1)
        layout.addLayout(row)

    # ---------- helpers ----------
    def _browse_out_dir(self):
        p = QFileDialog.getExistingDirectory(self, "Select output directory", self.out_dir.text().strip() or ".")
        if p:
            self.out_dir.setText(p)

    def _random_seed(self):
        self.seed.setText(str(int(time.time() * 1000) & 0x7FFFFFFF))

    def _apply_theme(self):
        name = self.theme_combo.currentText().strip()
        if name in self.themes:
            self.apply_theme_cb(self.themes[name])

    def _log(self, msg: str):
        self.log_view.append(msg)

    def _set_status(self, s: str):
        s2 = s if (s and s.strip()) else "thinking..."
        self.status_label.setText(s2)

    def _set_progress(self, p: int):
        self.progress_bar.setValue(int(max(0, min(100, p))))

    def _collect_cfg(self) -> SongConfig:
        cfg = SongConfig()

        cfg.out_dir = self.out_dir.text().strip() or "mods_out"
        seed_txt = self.seed.text().strip()
        cfg.seed = int(seed_txt) if seed_txt else None

        cfg.speed = int(self.speed.value())
        cfg.tempo = int(self.tempo.value())

        kr = self.key_root.currentText().strip()
        cfg.key_root_override = None if kr == "Random" else kr

        cfg.scale_mode = self.scale_mode.currentText().strip()
        cfg.variation = float(self.variation.value())
        cfg.stereo_width = float(self.stereo.value())

        mel = self.melody.currentText().strip()
        cfg.melody_name = None if mel == "Random" else mel
        cfg.derive_mode = self.derive.currentText().strip()

        cfg.instruments = [cb.currentText().strip() for cb in self.inst]

        cfg.enable_slowdown = self.chk_slowdown.isChecked()
        cfg.disable_vibrato = self.chk_vibrato.isChecked()
        cfg.fadeout_pattern = self.chk_fadeout.isChecked()
        cfg.compat_mode = self.chk_compat.isChecked()

        cfg.ralph_loop = self.chk_ralph.isChecked()
        cfg.ralph_target_score = float(self.ralph_target.value())
        cfg.ralph_max_attempts = int(self.ralph_attempts.value())

        # custom samples
        cfg.custom_sample_paths = dict(self.cfg.custom_sample_paths)

        return cfg

    # ---------- generation ----------
    def _start_generation(self):
        self.playback.stop()
        self.btn_play_song.setEnabled(False)
        self.preview_wav = None

        cfg = self._collect_cfg()
        self.cfg = cfg

        self._log("[ui] starting generation…")
        self._set_status("thinking...")
        self._set_progress(0)

        self.btn_generate.setEnabled(False)

        self.worker = GenerationWorker(cfg)
        self.worker.status.connect(self._set_status)
        self.worker.progress.connect(self._set_progress)
        self.worker.log.connect(self._log)
        self.worker.finished.connect(self._on_generated)
        self.worker.rendered.connect(self._on_rendered)
        self.worker.finished.connect(lambda *_: self.btn_generate.setEnabled(True))
        self.worker.start()

    def _on_generated(self, mod_path: object, song: object, q: object):
        self.last_mod_path = Path(mod_path)
        self.last_song = song
        self.last_quality = q

        qtxt = ""
        if q is not None:
            qtxt = f" | Ralph score {q.ralph_score:.1f}% (harmony {q.harmony_score:.1f} / melody {q.melody_score:.1f})"
        self.gen_result.setText(f"Generated: {self.last_mod_path}{qtxt}")

        self._refresh_patterns()

    def _on_rendered(self, wav_bytes: bytes):
        self.preview_wav = wav_bytes
        self.btn_play_song.setEnabled(True)
        self._log("[render] preview ready")

    def _play_preview(self):
        if not self.preview_wav:
            self._log("[play] no preview yet (render still running?)")
            return
        self.playback.play_wav_bytes(self.preview_wav)
        self._log("[play] preview playback started")

    def _stop_playback(self):
        self.playback.stop()
        self._log("[play] stop")

    # ---------- samples ----------
    def _import_sample(self, ch: int):
        path, _ = QFileDialog.getOpenFileName(self, f"Import WAV for CH{ch+1}", "", "WAV files (*.wav);;All files (*.*)")
        if path:
            self.cfg.custom_sample_paths[ch] = path
            self.sample_path_labels[ch].setText(Path(path).name)
            self._log(f"[sample] CH{ch+1}: imported {Path(path).name}")

    def _reset_sample(self, ch: int):
        if ch in self.cfg.custom_sample_paths:
            del self.cfg.custom_sample_paths[ch]
        self.sample_path_labels[ch].setText("Generated")
        self._log(f"[sample] CH{ch+1}: reset to generated")

    def _play_sample(self, ch: int):
        # custom wav?
        if ch in self.cfg.custom_sample_paths:
            wavb = self.sample_engine.preview_wav_from_custom_path(self.cfg.custom_sample_paths[ch])
            if wavb:
                self.playback.play_wav_bytes(wavb)
                self._log(f"[sample] CH{ch+1}: playing custom wav")
                return
            self._log(f"[sample] CH{ch+1}: custom wav unreadable")

        # generated preview
        inst_kind = self.inst[ch].currentText().strip()
        spec = SamplePreviewSpec(instrument_kind=inst_kind, disable_vibrato=self.chk_vibrato.isChecked(), seed=self.cfg.seed)
        wavb = self.sample_engine.preview_wav_for(spec)
        self.playback.play_wav_bytes(wavb)
        self._log(f"[sample] CH{ch+1}: playing {inst_kind} preview")

    # ---------- patterns ----------
    def _refresh_patterns(self):
        self.pattern_sel.blockSignals(True)
        self.pattern_sel.clear()

        if not self.last_song:
            self.pattern_sel.addItem("—")
            self.pattern_sel.blockSignals(False)
            self.pattern_view.setPlainText("")
            self.pattern_hint.setText("Generate a song to see patterns here.")
            return

        n = len(self.last_song.patterns)
        for i in range(n):
            self.pattern_sel.addItem(f"{i:02d}")

        self.pattern_sel.blockSignals(False)
        self.pattern_hint.setText(f"{n} patterns available. Select one to preview.")
        self._update_pattern_preview()

    def _update_pattern_preview(self):
        if not self.last_song:
            self.pattern_view.setPlainText("")
            return
        try:
            idx = self.pattern_sel.currentIndex()
            if idx < 0:
                return
            order_positions = order_positions_for_pattern(self.last_song.order, idx)
            txt = format_pattern(self.last_song.patterns[idx], idx, order_positions=order_positions)
            self.pattern_view.setPlainText(txt)
        except Exception as e:
            self.pattern_view.setPlainText(f"[pattern preview error] {e}")
