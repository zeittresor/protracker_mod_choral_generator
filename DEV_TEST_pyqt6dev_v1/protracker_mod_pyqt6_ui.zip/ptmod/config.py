from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, List, Dict

@dataclass
class SongConfig:
    # Output / determinism
    out_dir: str = "mods_out"
    seed: Optional[int] = None

    # Music params
    speed: int = 6
    tempo: int = 125
    instruments: List[str] = field(default_factory=lambda: ["Piano","Piano","Piano","Piano"])
    melody_name: Optional[str] = None          # None means Random
    derive_mode: str = "Random"                # Random / Near / Far
    key_root_override: Optional[str] = None    # e.g. C-2
    scale_mode: str = "Auto"                   # Auto/Major/Minor/Mixed/Dorian/Mixolydian
    variation: float = 0.65
    stereo_width: float = 1.0
    mute_channels: List[bool] = field(default_factory=lambda: [False, False, False, False])
    octave_spans: List[int] = field(default_factory=lambda: [3,3,3,3])

    # Compat / rendering options
    enable_slowdown: bool = True
    disable_vibrato: bool = False
    fadeout_pattern: bool = False
    compat_mode: bool = True                   # tracker compatibility safeguards
    mod_signature: Optional[str] = None         # M.K. / M!K!

    # Quality
    quality_passes: int = 3

    # Ralph loop (external meta-loop)
    ralph_loop: bool = False
    ralph_target_score: float = 90.0           # target for (harmony+melody)/2
    ralph_max_attempts: int = 50

    # Custom samples (optional): per channel path to wav
    custom_sample_paths: Dict[int, str] = field(default_factory=dict)

    def ensure_out_dir(self) -> Path:
        p = Path(self.out_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p
