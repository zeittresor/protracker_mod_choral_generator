from __future__ import annotations
from typing import Optional
import os
import time
from pathlib import Path

# Reuse the proven backend player (winsound / simpleaudio fallback)
from protracker_mod_choral_generator import Player

class PlaybackEngine:
    def __init__(self):
        self.player = Player()

    def stop(self):
        self.player.stop()

    def play_wav_bytes(self, wav_bytes: bytes):
        self.player.play(wav_bytes)

    def is_playing(self) -> bool:
        return self.player.is_playing()

    def playback_sample_index(self) -> int:
        return self.player.playback_sample_index()
