from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
from typing import Callable, Optional, Tuple, Any
import os

from ptmod.config import SongConfig
from ptmod.engines.quality_engine import evaluate_patterns_for_ralph, QualityResult

# Legacy backend (proven song generator)
import protracker_mod_choral_generator as backend


StatusCb = Optional[Callable[[str], None]]
ProgressCb = Optional[Callable[[int], None]]
LogCb = Optional[Callable[[str], None]]

def _cb(cb, *args, **kwargs):
    try:
        if cb:
            cb(*args, **kwargs)
    except Exception:
        pass

def _seed_for_attempt(base_seed: int, attempt: int) -> int:
    # Spread seeds aggressively so retries are not "near-duplicates"
    return int(base_seed) ^ (attempt * 0x9E3779B1) ^ ((attempt + 17) * 0x85EBCA6B)

def generate_song_once(cfg: SongConfig,
                       status_cb: StatusCb = None,
                       progress_cb: ProgressCb = None,
                       log_cb: LogCb = None) -> Tuple[Path, Any, Optional[QualityResult]]:
    _cb(status_cb, "thinking...")
    _cb(progress_cb, 2)

    # Normalize melody selection
    mel = None if (cfg.melody_name in (None, "", "Random")) else cfg.melody_name

    # Generate
    path, song = backend.generate_song(
        out_dir=cfg.out_dir,
        seed=cfg.seed,
        order=None,
        enable_slowdown=cfg.enable_slowdown,
        speed=int(cfg.speed),
        tempo=int(cfg.tempo),
        instruments=list(cfg.instruments),
        melody_name=mel,
        derive_mode=str(cfg.derive_mode),
        disable_vibrato=bool(cfg.disable_vibrato),
        key_root_override=cfg.key_root_override,
        scale_mode=str(cfg.scale_mode),
        variation=float(cfg.variation),
        mute_channels=list(cfg.mute_channels),
        stereo_width=float(cfg.stereo_width),
        octave_spans=list(cfg.octave_spans),
        mod_signature=cfg.mod_signature,
        compat_mode=bool(cfg.compat_mode),
        fadeout_pattern=bool(cfg.fadeout_pattern),
        quality_passes=int(cfg.quality_passes),
    )
    _cb(progress_cb, 55)

    # Quality for Ralph (optional)
    q = None
    try:
        root = getattr(song, "key_root", cfg.key_root_override or "C-2")
        scale = getattr(song, "scale_mode", cfg.scale_mode or "Auto")
        q = evaluate_patterns_for_ralph(song.patterns, scale, root)
    except Exception as e:
        _cb(log_cb, f"[quality] failed: {e}")

    _cb(progress_cb, 100)
    _cb(status_cb, "ready")
    return Path(path), song, q

def generate_with_ralph_loop(cfg: SongConfig,
                             status_cb: StatusCb = None,
                             progress_cb: ProgressCb = None,
                             log_cb: LogCb = None) -> Tuple[Path, Any, Optional[QualityResult]]:
    """
    External retry loop: repeatedly generate complete songs until the requested
    harmony+melody score (Ralph score) is reached, or max attempts is hit.
    Keeps the best result.
    """
    if not cfg.ralph_loop:
        return generate_song_once(cfg, status_cb, progress_cb, log_cb)

    # Base seed (deterministic if provided, else use backend generator)
    base_seed = int(cfg.seed) if cfg.seed is not None else int(backend.random_seed_value())

    best_path: Optional[Path] = None
    best_song: Any = None
    best_q: Optional[QualityResult] = None
    best_score = -1.0

    max_attempts = max(1, int(cfg.ralph_max_attempts or 50))
    target = float(cfg.ralph_target_score or 90.0)

    for attempt in range(max_attempts):
        attempt_seed = _seed_for_attempt(base_seed, attempt)
        cfg_local = SongConfig(**asdict(cfg))
        cfg_local.seed = attempt_seed

        _cb(status_cb, f"ralph is retrying (give him a chance) {max(0.0, min(100.0, best_score)):.1f}%")
        _cb(progress_cb, int((attempt / max_attempts) * 45) + 1)
        _cb(log_cb, f"[ralph] attempt {attempt+1}/{max_attempts}, seed={attempt_seed}")

        path, song, q = generate_song_once(cfg_local, status_cb=None, progress_cb=None, log_cb=log_cb)

        score = float(q.ralph_score) if q is not None else 0.0
        _cb(log_cb, f"[ralph] score={score:.1f} (target={target:.1f})  harmony={getattr(q,'harmony_score',0):.1f} melody={getattr(q,'melody_score',0):.1f}" if q else f"[ralph] score={score:.1f}")

        if score > best_score:
            # Remove previous best file to avoid clutter
            try:
                if best_path and best_path.exists():
                    best_path.unlink(missing_ok=True)  # py3.11
            except Exception:
                pass
            best_score = score
            best_path, best_song, best_q = Path(path), song, q
            _cb(status_cb, f"ralph is retrying (give him a chance) {best_score:.1f}%")

        else:
            # Not best -> delete this attempt's MOD
            try:
                Path(path).unlink(missing_ok=True)
            except Exception:
                pass

        if best_score >= target:
            _cb(log_cb, f"[ralph] target reached at attempt {attempt+1}: {best_score:.1f}")
            break

    _cb(progress_cb, 100)
    _cb(status_cb, "ready")
    # Safety fallback (should never be None)
    if best_path is None:
        return generate_song_once(cfg, status_cb, progress_cb, log_cb)
    return best_path, best_song, best_q
