# ProTracker MOD Choral Generator — PyQt6 UI (experimental)

This folder adds a **new PyQt6-based GUI** on top of the existing generator backend (`protracker_mod_choral_generator.py`).
It also starts the modular split into small “engines” (see `ptmod/engines/`), similar to the existing `harmony_analyzer.py`.

## Features in this UI

- Generates `.mod` files using the existing backend generator
- Optional **Ralph-Loop** (retry until `((harmony + melody)/2) >= target`, default 90%, max 50 attempts)
- Renders a WAV preview automatically after generation and can play it
- Sample previews are always playable (custom WAV or synthesized from chosen instrument)
- Pattern preview (monospaced ProTracker-style text)
- Theme system:
  - **Modern Dark**
  - **Modern Light**
  - **Amiga ECS** (Workbench-ish high contrast)
  - **Amiga MUI** (soft gray bevel vibe)
  - plus any custom `themes/*.qss`

## Quick start (Windows)

Double-click:

- `run_windows.bat`

It will create a venv, install dependencies, then start the app.

## Quick start (manual)

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```

## Custom themes

Drop `.qss` files into:

- `themes/`

Restart the app; the theme appears in the theme dropdown.

## Notes / status

- This is an **alternative UI**, not a replacement: the Tkinter GUI inside `protracker_mod_choral_generator.py` is still there.
- If you want to go “full refactor”, the next logical step is to move more backend code into `ptmod/engines/` and keep the legacy file as a thin wrapper.
