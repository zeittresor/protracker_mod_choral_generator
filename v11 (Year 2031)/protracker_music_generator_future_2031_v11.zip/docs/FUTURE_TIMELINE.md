# Protracker Music Generator – Future Edition 2031 (speculative snapshot)

This file is a *fictional* “where we ended up after 5 years” projection based on the project’s real evolution.

## 2026 → 2031 (highlights)

### 2026
- PyQt6 migration stabilized: themes, global scroll, robust playback.
- Ralph-Loop became default (quality target + retries).
- PT2 compatibility mode hardened (C-1..B-3, M.K., strict periods).

### 2027
- Plugin ecosystem: “melody plugins” matured (metadata, pattern-order hints, folders).
- Batch generation UX: generate many variants, keep best, compare A/B.
- Library concept: auto-save outputs, WAV previews, ratings, tags.

### 2028
- Hijack tab expanded: MIDI import became first-class.
- Long MIDI sources: random windowing & sequential window traversal.
- Motif influence slider (8/16/32/64) made “how much the source shapes the song” explicit.

### 2029
- Export pipeline: presets as JSON, plugins as portable zip packs.
- Offline-first: everything works without internet by design.

### 2030
- “Lab” feature-gates: experimental structure engines, novelty guard, micro-FX.
- Lots of debates about what should be default vs. opt-in (spoiler: defaults stayed conservative).

### 2031
- Studio workflow: generate → auto-library → rate → iterate.
- The project is still *tracker-centric* (limitations embraced), but with modern UX.

## Design principles that survived every argument
- **Offline-first**, beginner-friendly.
- **Strict compatibility options** for classic trackers, but optional advanced modes.
- **Separation of engines** (generation / samples / FX / quality / UI).

