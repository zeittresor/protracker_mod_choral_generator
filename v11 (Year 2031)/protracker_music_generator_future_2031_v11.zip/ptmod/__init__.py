from .config import SongConfig

__version__ = "11.0"
