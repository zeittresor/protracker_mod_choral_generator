from __future__ import annotations

import os
import sys
import time
import random
import subprocess
from dataclasses import asdict
from pathlib import Path
from typing import Optional, Any

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QFont, QDesktopServices
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QTabWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QSplitter,
    QLabel, QPushButton, QLineEdit, QComboBox, QSpinBox, QCheckBox, QTextEdit,
    QFileDialog, QGroupBox, QProgressBar, QStatusBar, QSlider, QScrollArea, QSizePolicy, QFrame,
    QListWidget, QListWidgetItem, QPlainTextEdit, QMessageBox
)

import protracker_mod_choral_generator as backend

from ptmod.config import SongConfig
from ptmod import __version__
from ptmod.engines.playback_engine import PlaybackEngine
from ptmod.engines.sample_engine import SampleEngine, SamplePreviewSpec
from ptmod.engines.pattern_engine import format_pattern, order_positions_for_pattern
from ptmod.engines.generator_engine import generate_batch
from ptmod.engines.library_engine import add_to_library, scan_library, library_root, update_rating
from ptmod.engines.preset_engine import save_preset, load_preset, presets_root
from ptmod.engines.plugins_engine import reload_plugins, plugin_root, open_folder, add_last_as_plugin, import_midi_as_plugin, get_recommended_pattern_order, get_plugin_meta
from ptmod.ui.i18n import I18N, LANG_CHOICES
from ptmod.ui.visualizer import VisualizerWidget


class GenerationWorker(QThread):
    status = pyqtSignal(str)
    progress = pyqtSignal(int)
    log = pyqtSignal(str)
    song_ready = pyqtSignal(object, object, object)  # (Path, SongData, QualityResult|None)
    preview_ready = pyqtSignal(bytes, bytes, int)    # (wav_bytes, pcm16_bytes, sample_rate)

    def __init__(self, cfg: SongConfig):
        super().__init__()
        self.cfg = cfg
        self._preview_rate = 44100
        self._cancel = False

    def request_cancel(self):
        self._cancel = True

    def run(self):
        try:
            self.status.emit("thinking...")
            self.progress.emit(0)

            def _st(s: str):
                self.status.emit(s if (s and s.strip()) else "thinking...")

            def _pr(p: int):
                self.progress.emit(int(max(0, min(100, p))))

            def _lg(s: str):
                self.log.emit(str(s))

            last = None
            for mod_path, song, q in generate_batch(self.cfg, status_cb=_st, progress_cb=_pr, log_cb=_lg):
                if self._cancel:
                    _lg("[cancel] requested")
                    break
                last = (mod_path, song, q)
                self.song_ready.emit(mod_path, song, q)

                # Optional: export WAV and params per cfg
                if bool(getattr(self.cfg, 'save_params', True)):
                    try:
                        backend.save_song_parameters_txt(Path(mod_path), song)
                    except Exception as e:
                        _lg(f"[save_params] failed: {e}")
                if bool(getattr(self.cfg, 'export_wav', True)):
                    try:
                        self.status.emit("thinking...")
                        self.progress.emit(0)
                        def _render_prog(done: int, total: int):
                            pct = 0.0 if total <= 0 else (done / float(total)) * 100.0
                            self.status.emit(f"render {pct:.0f}%")
                            self.progress.emit(int(pct))
                        pcm16, sr, _chbufs = backend.render_song_to_pcm16(song, out_rate=self._preview_rate, progress_cb=_render_prog, cancel_event=None)
                        wavb = backend.pcm16_to_wav_bytes(pcm16, sr, nch=2)
                        wav_path = Path(mod_path).with_suffix('.wav')
                        if not wav_path.exists():
                            wav_path.write_bytes(wavb)
                        self.preview_ready.emit(wavb, pcm16, int(sr))
                    except Exception as e:
                        _lg(f"[export_wav] failed: {e}")

            # If not exporting WAV, still render preview for last song to enable PLAY + visualizer
            if last is not None and not bool(getattr(self.cfg, 'export_wav', True)):
                mod_path, song, q = last
                self.status.emit("thinking...")
                self.progress.emit(0)
                def _render_prog(done: int, total: int):
                    pct = 0.0 if total <= 0 else (done / float(total)) * 100.0
                    self.status.emit(f"render {pct:.0f}%")
                    self.progress.emit(int(pct))
                pcm16, sr, _chbufs = backend.render_song_to_pcm16(song, out_rate=self._preview_rate, progress_cb=_render_prog, cancel_event=None)
                wavb = backend.pcm16_to_wav_bytes(pcm16, sr, nch=2)
                self.preview_ready.emit(wavb, pcm16, int(sr))

            self.status.emit("ready")
            self.progress.emit(100)
        except Exception as e:
            self.log.emit(f"[error] {e}")
            self.status.emit("ready")
            self.progress.emit(0)


class MainWindow(QMainWindow):
    def __init__(self, themes: dict, apply_theme_cb):
        super().__init__()
        self.setWindowTitle(f"Protracker Music Generator - v{__version__} (Future Edition 2031)")
        self._order_user_modified = False
        self._last_auto_order: str | None = None
        self._motif_user_modified = False

        self.resize(1120, 820)

        self.themes = themes
        self.apply_theme_cb = apply_theme_cb

        self.i18n = I18N("English")
        self.cfg = SongConfig()

        self.last_song: Optional[Any] = None
        self.last_mod_path: Optional[Path] = None
        self.last_quality: Optional[Any] = None
        self.preview_wav: Optional[bytes] = None
        self.preview_pcm16: Optional[bytes] = None
        self.preview_sr: int = 44100

        self.playback = PlaybackEngine()

        # Poll playback to keep STOP/PLAY state and visualizer running across backends
        self._play_poll = QTimer(self)
        self._play_poll.timeout.connect(self._poll_playback_state)
        self._play_poll.start(200)
        self._was_playing = False
        self.sample_engine = SampleEngine()
        self.worker: Optional[GenerationWorker] = None

        self._build_ui()
        self._apply_language()

    # ---------- UI ----------
    def _build_ui(self):
        root_content = QWidget()
        app_scroll = QScrollArea()
        app_scroll.setWidgetResizable(True)
        app_scroll.setFrameShape(QFrame.Shape.NoFrame)
        app_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        app_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        app_scroll.setWidget(root_content)
        self.setCentralWidget(app_scroll)
        outer = QVBoxLayout(root_content)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        outer.addWidget(splitter, 1)

        # Left sidebar (scrollable controls + fixed action buttons)
        # Reason: sidebar content can exceed window height; Qt will then shrink groupboxes to near-zero
        # height (labels become unreadable). A scroll area preserves preferred sizes.
        left = QWidget()
        left_outer = QVBoxLayout(left)
        left_outer.setContentsMargins(8, 8, 8, 8)
        left_outer.setSpacing(8)

        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.Shape.NoFrame)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        left_content = QWidget()
        left_l = QVBoxLayout(left_content)
        left_l.setContentsMargins(0, 0, 0, 0)
        left_l.setSpacing(8)

        # Pattern order
        grp_order = QGroupBox(self.i18n.tr("PATTERN ORDER"))
        g = QGridLayout(grp_order)
        self.btn_smart = QPushButton(self.i18n.tr("SMART"))
        self.btn_smart.clicked.connect(self._smart_order)
        self.order_combo = QComboBox()
        self.order_combo.setEditable(True)
        try:
            le = self.order_combo.lineEdit()
            if le is not None:
                le.textEdited.connect(self._on_order_user_edit)
        except Exception:
            pass

        try:
            for p in getattr(backend, 'ORDER_PRESETS', []):
                self.order_combo.addItem(str(p))
        except Exception:
            pass
        self.order_combo.setCurrentText(getattr(backend, 'DEFAULT_ORDER_STR', '0,1,2,3,4,5'))
        g.addWidget(self.order_combo, 0, 0, 1, 2)
        g.addWidget(self.btn_smart, 1, 1)
        self.chk_use_smart = QCheckBox(self.i18n.tr("SMART"))
        self.chk_use_smart.setChecked(False)
        g.addWidget(self.chk_use_smart, 1, 0)
        left_l.addWidget(grp_order)

        # Base melody + derivation
        grp_mel = QGroupBox(self.i18n.tr("BASE MELODY"))
        gm = QGridLayout(grp_mel)
        self.melody_combo = QComboBox()
        self.melody_combo.currentTextChanged.connect(self._on_melody_selected)
        self._reload_melodies(initial=True)
        gm.addWidget(self.melody_combo, 0, 0, 1, 2)
        gm.addWidget(QLabel(self.i18n.tr("MELODY DERIVATION")), 1, 0)
        self.derive_combo = QComboBox()
        self.derive_combo.addItems(["Random", "Near", "Far"])
        gm.addWidget(self.derive_combo, 1, 1)
        left_l.addWidget(grp_mel)

        # Key root + random
        grp_key = QGroupBox(self.i18n.tr("BASE KEY (optional)"))
        gk = QHBoxLayout(grp_key)
        self.key_edit = QLineEdit("")
        self.key_edit.setPlaceholderText("C-2")
        self.btn_key_rnd = QPushButton("RND")
        self.btn_key_rnd.clicked.connect(self._random_key)
        gk.addWidget(self.key_edit, 1)
        gk.addWidget(self.btn_key_rnd)
        left_l.addWidget(grp_key)

        # Speed / tempo
        grp_st = QGroupBox(self.i18n.tr("SPEED") + " / " + self.i18n.tr("TEMPO"))
        gst = QGridLayout(grp_st)
        gst.addWidget(QLabel(self.i18n.tr("SPEED")), 0, 0)
        self.speed = QSpinBox(); self.speed.setRange(1, 31); self.speed.setValue(6)
        gst.addWidget(self.speed, 0, 1)
        gst.addWidget(QLabel(self.i18n.tr("TEMPO")), 1, 0)
        self.tempo = QSpinBox(); self.tempo.setRange(32, 255); self.tempo.setValue(125)
        gst.addWidget(self.tempo, 1, 1)
        left_l.addWidget(grp_st)

        # Advanced
        grp_adv = QGroupBox("Advanced")
        ga = QGridLayout(grp_adv)

        ga.addWidget(QLabel(self.i18n.tr("SCALE MODE")), 0, 0)
        self.scale_combo = QComboBox()
        for s in getattr(backend, 'SCALE_MODE_CHOICES', ["Auto","Major","Minor"]):
            self.scale_combo.addItem(s)
        self.scale_combo.setCurrentText("Major")
        ga.addWidget(self.scale_combo, 0, 1)

        ga.addWidget(QLabel(self.i18n.tr("VARIATION")), 1, 0)
        self.var_slider = QSlider(Qt.Orientation.Horizontal)
        self.var_slider.setRange(0, 100)
        self.var_slider.setValue(65)
        ga.addWidget(self.var_slider, 1, 1)

        ga.addWidget(QLabel(self.i18n.tr("SEED (optional)")), 2, 0)
        self.seed_edit = QLineEdit("")
        self.btn_seed_rnd = QPushButton("RND")
        self.btn_seed_rnd.clicked.connect(self._random_seed)
        seed_row = QHBoxLayout()
        seed_row.addWidget(self.seed_edit, 1)
        seed_row.addWidget(self.btn_seed_rnd)
        seed_wrap = QWidget(); seed_wrap.setLayout(seed_row)
        ga.addWidget(seed_wrap, 2, 1)

        self.chk_auto_seed = QCheckBox(self.i18n.tr("NEW SEED EACH GENERATE"))
        self.chk_auto_seed.setChecked(True)
        ga.addWidget(self.chk_auto_seed, 3, 0, 1, 2)

        ga.addWidget(QLabel(self.i18n.tr("BATCH")), 4, 0)
        self.batch = QSpinBox(); self.batch.setRange(1, 50); self.batch.setValue(1)
        ga.addWidget(self.batch, 4, 1)

        ga.addWidget(QLabel(self.i18n.tr("MUTE CH")), 5, 0)
        mute_row = QHBoxLayout()
        self.mute = [QCheckBox(str(i+1)) for i in range(4)]
        for cb in self.mute:
            mute_row.addWidget(cb)
        mute_wrap = QWidget(); mute_wrap.setLayout(mute_row)
        ga.addWidget(mute_wrap, 5, 1)

        ga.addWidget(QLabel(self.i18n.tr("STEREO %")), 6, 0)
        self.stereo_slider = QSlider(Qt.Orientation.Horizontal)
        self.stereo_slider.setRange(0, 200)
        self.stereo_slider.setValue(100)
        ga.addWidget(self.stereo_slider, 6, 1)

        ga.addWidget(QLabel(self.i18n.tr("PASSES")), 7, 0)
        self.passes = QComboBox()
        self.passes.addItems(["1","2","3","4","5"])
        self.passes.setCurrentText("3")
        ga.addWidget(self.passes, 7, 1)

        left_l.addWidget(grp_adv)

        # Instruments (CH1..CH4) + octave span
        grp_inst = QGroupBox(self.i18n.tr("INSTRUMENTS (CH1..CH4)"))
        gi = QGridLayout(grp_inst)
        self.btn_inst_rnd = QPushButton("RND")
        self.btn_inst_rnd.clicked.connect(self._randomize_instruments)
        gi.addWidget(self.btn_inst_rnd, 0, 1, alignment=Qt.AlignmentFlag.AlignRight)
        self.inst = []
        self.octv = []
        inst_choices = list(getattr(backend, 'INSTRUMENT_CHOICES', ["Piano"]))
        for ch in range(4):
            gi.addWidget(QLabel(f"CH{ch+1}"), ch+1, 0)
            row = QHBoxLayout()
            cb = QComboBox(); cb.addItems(inst_choices); cb.setCurrentText("Piano")
            # Keep Samples tab labels in sync with instrument selection.
            cb.currentTextChanged.connect(lambda _t=None: self._refresh_sample_display())
            oc = QComboBox(); oc.addItems(["1","2","3"])
            oc.setCurrentText("2" if ch==2 else "3")
            row.addWidget(cb, 1)
            row.addWidget(oc)
            wrap = QWidget(); wrap.setLayout(row)
            gi.addWidget(wrap, ch+1, 1)
            self.inst.append(cb)
            self.octv.append(oc)
        left_l.addWidget(grp_inst)

        # Keep groupboxes readable: prefer fixed vertical sizing (scroll handles overflow)
        for _gb in (grp_order, grp_mel, grp_key, grp_st, grp_adv, grp_inst):
            _gb.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            _gb.setMinimumHeight(_gb.sizeHint().height())

        left_l.addStretch(1)

        left_scroll.setWidget(left_content)
        left_outer.addWidget(left_scroll, 1)

        # Fixed action buttons (always visible)
        btn_panel = QWidget()
        btn_panel_l = QVBoxLayout(btn_panel)
        btn_panel_l.setContentsMargins(0, 0, 0, 0)
        btn_panel_l.setSpacing(8)

        btn_row1 = QHBoxLayout()
        self.btn_gen = QPushButton(self.i18n.tr("GENERATE"))
        self.btn_regen = QPushButton(self.i18n.tr("RE-GENERATE"))
        self.btn_play = QPushButton(self.i18n.tr("PLAY"))
        self.btn_stop = QPushButton(self.i18n.tr("STOP"))
        self.btn_gen.clicked.connect(self._on_generate)
        self.btn_regen.clicked.connect(self._on_regenerate)
        self.btn_play.clicked.connect(self._on_play)
        self.btn_stop.clicked.connect(self._on_stop)

        btn_row1.addWidget(self.btn_gen)
        btn_row1.addWidget(self.btn_regen)
        btn_row1.addWidget(self.btn_play)
        btn_row1.addWidget(self.btn_stop)
        btn_wrap1 = QWidget(); btn_wrap1.setLayout(btn_row1)
        btn_panel_l.addWidget(btn_wrap1)

        btn_row2 = QGridLayout()
        self.btn_open_out = QPushButton(self.i18n.tr("OPEN OUTPUT"))
        self.btn_open_plg = QPushButton(self.i18n.tr("OPEN PLUGINS"))
        self.btn_refresh = QPushButton(self.i18n.tr("REFRESH"))
        self.btn_add_plg = QPushButton(self.i18n.tr("ADD AS PLUGIN"))
        self.btn_open_out.clicked.connect(self._open_output)
        self.btn_open_plg.clicked.connect(self._open_plugins)
        self.btn_refresh.clicked.connect(self._reload_melodies)
        self.btn_add_plg.clicked.connect(self._add_as_plugin)

        btn_row2.addWidget(self.btn_open_out, 0, 0)
        btn_row2.addWidget(self.btn_open_plg, 0, 1)
        btn_row2.addWidget(self.btn_refresh, 1, 0)
        btn_row2.addWidget(self.btn_add_plg, 1, 1)
        btn_wrap2 = QWidget(); btn_wrap2.setLayout(btn_row2)
        btn_panel_l.addWidget(btn_wrap2)

        left_outer.addWidget(btn_panel, 0)

        splitter.addWidget(left)

        # Right tabs
        self.tabs = QTabWidget()
        self.tabs.currentChanged.connect(self._on_tab_changed)
        splitter.addWidget(self.tabs)
        splitter.setStretchFactor(1, 1)

        self._tab_main()
        self._tab_samples()
        self._tab_options()
        self._tab_hijack()
        # Future Edition tabs
        self._tab_studio()
        self._tab_library()
        self._tab_export()
        self._tab_docs()
        self._tab_lab()

        self._refresh_sample_display()


        # Status bar
        sb = QStatusBar()
        self.setStatusBar(sb)
        self.status_label = QLabel("ready")
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedWidth(220)
        sb.addWidget(self.status_label, 1)
        sb.addPermanentWidget(self.progress_bar)

        # Initial UI state
        self.btn_play.setEnabled(False)
        self.btn_regen.setEnabled(False)
        # STOP availability is managed by playback poller
        self.btn_add_plg.setEnabled(False)

    def _tab_main(self):
        w = QWidget()
        self.tabs.addTab(w, self.i18n.tr("MAIN"))
        layout = QVBoxLayout(w)

        self.viz_title = QLabel(self.i18n.tr("SPECTRUM ANALYZER"))
        self.viz_title.setStyleSheet("font-size: 14px;")
        self.viz_hint = QLabel(self.i18n.tr("Click visualizer to toggle Spectrum / Scopes") if hasattr(self.i18n, 'tr') else "Click visualizer to toggle")
        layout.addWidget(self.viz_title)
        layout.addWidget(self.viz_hint)

        self.visualizer = VisualizerWidget()
        self.visualizer.set_playhead_callback(self.playback.playhead_frame_index)
        layout.addWidget(self.visualizer)

        # Render/harmony row
        row = QHBoxLayout()
        self.render_lbl = QLabel("")
        self.render_lbl.setStyleSheet("font-size: 16px;")
        self.harmony_lbl = QLabel("Harmony: --%")
        row.addWidget(self.render_lbl, 1)
        row.addWidget(self.harmony_lbl, 0)
        layout.addLayout(row)

        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMinimumHeight(120)
        self.log_text.append("Generate a song, then hit PLAY.")
        layout.addWidget(self.log_text)

        # Pattern preview
        head = QHBoxLayout()
        head.addWidget(QLabel(self.i18n.tr("PATTERN PREVIEW")))
        self.pattern_sel = QComboBox()
        self.pattern_sel.addItem("0")
        self.pattern_sel.currentTextChanged.connect(self._update_pattern_preview)
        head.addWidget(self.pattern_sel)
        head.addStretch(1)
        layout.addLayout(head)

        self.pattern_text = QTextEdit()
        self.pattern_text.setReadOnly(True)
        font = QFont("Courier New")
        self.pattern_text.setFont(font)
        layout.addWidget(self.pattern_text, 1)

    def _tab_samples(self):
        w = QWidget()
        self.tabs.addTab(w, self.i18n.tr("SAMPLES"))
        layout = QVBoxLayout(w)

        self.sample_rows = []
        for ch in range(4):
            grp = QGroupBox(f"CH{ch+1}")
            g = QGridLayout(grp)
            self.sample_inst_lbl = QLabel("-")
            self.sample_status_lbl = QLabel("Generated")
            self.sample_vol_lbl = QLabel("-")
            btn_play = QPushButton(self.i18n.tr("PLAY"))
            btn_rep = QPushButton("Replace")
            btn_reset = QPushButton("Reset")
            btn_play.clicked.connect(lambda _=None, c=ch: self._play_sample(c))
            btn_rep.clicked.connect(lambda _=None, c=ch: self._replace_sample(c))
            btn_reset.clicked.connect(lambda _=None, c=ch: self._reset_sample(c))

            g.addWidget(QLabel("Instrument"), 0, 0)
            g.addWidget(self.sample_inst_lbl, 0, 1)
            g.addWidget(QLabel("Status"), 1, 0)
            g.addWidget(self.sample_status_lbl, 1, 1)
            g.addWidget(QLabel("Volume"), 2, 0)
            g.addWidget(self.sample_vol_lbl, 2, 1)

            g.addWidget(btn_play, 0, 2)
            g.addWidget(btn_rep, 1, 2)
            g.addWidget(btn_reset, 2, 2)

            self.sample_rows.append({
                "inst": self.sample_inst_lbl,
                "status": self.sample_status_lbl,
                "vol": self.sample_vol_lbl,
                "play": btn_play,
                "replace": btn_rep,
                "reset": btn_reset,
            })
            layout.addWidget(grp)

        btn_import_all = QPushButton("Import WAV (multi)")
        btn_import_all.clicked.connect(self._import_all_samples)
        layout.addWidget(btn_import_all)

        self.samples_info = QTextEdit()
        self.samples_info.setReadOnly(True)
        self.samples_info.setMinimumHeight(120)
        layout.addWidget(self.samples_info, 1)
        self._refresh_sample_display()

    def _tab_options(self):
        w = QWidget()
        self.tabs.addTab(w, self.i18n.tr("OPTIONS"))
        layout = QVBoxLayout(w)

        # Export options
        grp_export = QGroupBox("Export")
        ge = QVBoxLayout(grp_export)
        self.opt_export_wav = QCheckBox(self.i18n.tr("Export rendered songs as WAV"))
        self.opt_save_params = QCheckBox(self.i18n.tr("Save song parameters"))
        self.opt_disable_vibrato = QCheckBox(self.i18n.tr("Disable vibrato in samples"))
        self.opt_fadeout = QCheckBox(self.i18n.tr("Add empty fade-out pattern"))
        self.opt_slowdown = QCheckBox(self.i18n.tr("Enable slowdown to the end of the song"))

        self.opt_export_wav.setChecked(True)
        self.opt_save_params.setChecked(True)
        self.opt_disable_vibrato.setChecked(True)
        self.opt_fadeout.setChecked(True)
        self.opt_slowdown.setChecked(False)

        for cb in [self.opt_export_wav, self.opt_save_params, self.opt_disable_vibrato, self.opt_fadeout, self.opt_slowdown]:
            ge.addWidget(cb)
        layout.addWidget(grp_export)

        # Compatibility / signature
        grp_comp = QGroupBox(self.i18n.tr("Compatibility"))
        gc = QGridLayout(grp_comp)
        self.opt_compat = QCheckBox(self.i18n.tr("ProTracker 2 Compatibility Mode"))
        self.opt_compat.setChecked(True)
        self.opt_compat.setToolTip(
            "Strict ProTracker 2 / PT2-clone output.\n"
            "- Clamps notes into ProTracker range C-1 .. B-3\n"
            "- Forces M.K. signature (4 channels)\n"
            "- Sanitizes any off-table periods (avoids '???' notes)"
        )
        gc.addWidget(self.opt_compat, 0, 0, 1, 2)

        gc.addWidget(QLabel(self.i18n.tr("MOD Signature")), 1, 0)
        self.opt_sig = QComboBox()
        sig_items = [
            ("M.K. (ProTracker / 4ch)", "M.K."),
            ("M!K! (ProTracker alt / 4ch)", "M!K!"),
            ("FLT4 (StarTrekker / 4ch)", "FLT4"),
            ("4CHN (FastTracker / 4ch)", "4CHN"),
            ("N.T. (NoiseTracker / 4ch)", "N.T."),
            ("NSMS (NoiseTracker / 4ch)", "NSMS"),
            ("OKTA (Oktalyzer / 8ch tag)", "OKTA"),
            ("FLT8 (StarTrekker / 8ch tag)", "FLT8"),
            ("8CHN (FastTracker / 8ch tag)", "8CHN"),
        ]
        for label, sig in sig_items:
            self.opt_sig.addItem(label, sig)

        # Also include any backend-provided choices not already present
        try:
            for s in getattr(backend, 'MOD_SIGNATURE_CHOICES', []):
                s = str(s)
                if not any(str(self.opt_sig.itemData(i)) == s for i in range(self.opt_sig.count())):
                    self.opt_sig.addItem(f"{s} (Custom)", s)
        except Exception:
            pass

        default_sig = str(getattr(backend, 'DEFAULT_MOD_SIGNATURE', 'M!K!'))
        for i in range(self.opt_sig.count()):
            if str(self.opt_sig.itemData(i)) == default_sig:
                self.opt_sig.setCurrentIndex(i)
                break

        self.opt_sig.setToolTip(
            "Tracker signature tag (magic at offset 1080).\n"
            "Note: 8ch tags (OKTA/FLT8/8CHN) may confuse players because this generator outputs 4 channels."
        )
        gc.addWidget(self.opt_sig, 1, 1)
        layout.addWidget(grp_comp)

        # When PT2 compatibility is enabled, force a ProTracker signature.
        self.opt_compat.toggled.connect(self._on_pt2_compat_toggled)
        self._on_pt2_compat_toggled(self.opt_compat.isChecked())

        # Ralph loop
        grp_r = QGroupBox(self.i18n.tr("Ralph-Loop"))
        gr = QGridLayout(grp_r)
        self.opt_ralph = QCheckBox(self.i18n.tr("Ralph-Loop"))
        self.opt_ralph.setChecked(True)
        gr.addWidget(self.opt_ralph, 0, 0, 1, 2)
        gr.addWidget(QLabel("Target %"), 1, 0)
        self.opt_r_target = QSpinBox(); self.opt_r_target.setRange(0, 100); self.opt_r_target.setValue(85)
        gr.addWidget(self.opt_r_target, 1, 1)
        gr.addWidget(QLabel("Max attempts"), 2, 0)
        self.opt_r_attempts = QSpinBox(); self.opt_r_attempts.setRange(1, 200); self.opt_r_attempts.setValue(60)
        gr.addWidget(self.opt_r_attempts, 2, 1)
        self.opt_r_ignore_drums = QCheckBox(self.i18n.tr("Ignore drumset channels"))
        self.opt_r_ignore_drums.setChecked(True)
        self.opt_r_ignore_drums.setToolTip(self.i18n.tt("Ignore drumset channels"))
        gr.addWidget(self.opt_r_ignore_drums, 3, 0, 1, 2)
        # Melody influence (how many rows of the base melody motif should shape the whole song)
        grp_inf = QGroupBox(self.i18n.tr("Melody Influence"))
        gi = QGridLayout(grp_inf)
        gi.addWidget(QLabel(self.i18n.tr("Motif rows")), 0, 0)
        self._influence_values = [8, 16, 32, 64]
        self.inf_slider = QSlider(Qt.Orientation.Horizontal)
        self.inf_slider.setRange(0, len(self._influence_values) - 1)
        self.inf_slider.setValue(self._influence_values.index(64))
        self.inf_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.inf_slider.setTickInterval(1)
        self.inf_value_lbl = QLabel("64")
        self.inf_value_lbl.setMinimumWidth(40)

        def _upd_inf(v: int):
            try:
                self.inf_value_lbl.setText(str(self._influence_values[int(v)]))
            except Exception:
                self.inf_value_lbl.setText("64")
        self.inf_slider.valueChanged.connect(_upd_inf)
        try:
            self.inf_slider.sliderPressed.connect(lambda: setattr(self, "_motif_user_modified", True))
        except Exception:
            pass
        _upd_inf(self.inf_slider.value())

        gi.addWidget(self.inf_slider, 0, 1)
        gi.addWidget(self.inf_value_lbl, 0, 2)

        gi.addWidget(QLabel("8  |  16  |  32  |  64"), 1, 1, 1, 2)
        grp_inf.setToolTip(
            "How many rows from the selected base melody/preset should strongly influence the generated song.\n"
            "64 = full 1-pattern motif, 8 = only a short hook."
        )
        layout.addWidget(grp_inf)

        layout.addWidget(grp_r)

        # Theme
        grp_theme = QGroupBox(self.i18n.tr("Theme"))
        gt = QHBoxLayout(grp_theme)
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(list(self.themes.keys()))
        self.theme_combo.setCurrentText("ProTracker Gray" if "ProTracker Gray" in self.themes else list(self.themes.keys())[0])
        btn_apply = QPushButton("Apply")
        btn_apply.clicked.connect(self._apply_theme)
        gt.addWidget(self.theme_combo, 1)
        gt.addWidget(btn_apply)
        layout.addWidget(grp_theme)

        # Language
        grp_lang = QGroupBox(self.i18n.tr("LANGUAGE"))
        gl = QHBoxLayout(grp_lang)
        self.lang_combo = QComboBox()
        self.lang_combo.addItems(LANG_CHOICES)
        self.lang_combo.setCurrentText("English")
        self.lang_combo.currentTextChanged.connect(self._on_lang_change)
        gl.addWidget(self.lang_combo)
        layout.addWidget(grp_lang)

        # Help / Manual (AmigaGuide-like viewer)
        grp_help = QGroupBox(self.i18n.tr("Help"))
        gh = QHBoxLayout(grp_help)
        btn_help = QPushButton(self.i18n.tr("Help"))
        btn_help.clicked.connect(self._open_help_viewer)
        gh.addWidget(btn_help)
        layout.addWidget(grp_help)

        # FX injection
        grp_fx = QGroupBox(self.i18n.tr("FX Injection"))
        gfx = QGridLayout(grp_fx)
        self.fx_init = QCheckBox(self.i18n.tr("Insert initial speed/tempo"))
        self.fx_init.setChecked(True)
        self.fx_vib = QCheckBox(self.i18n.tr("Vibrato on melody"))
        self.fx_porta = QCheckBox(self.i18n.tr("Portamento transitions"))
        self.fx_arp = QCheckBox(self.i18n.tr("Arpeggio ornaments"))
        self.fx_vol = QCheckBox(self.i18n.tr("Volume motion"))
        self.fx_cut = QCheckBox(self.i18n.tr("Note cut"))
        self.fx_retrig = QCheckBox(self.i18n.tr("Retrig"))
        gfx.addWidget(self.fx_init, 0, 0, 1, 2)
        gfx.addWidget(self.fx_vib, 1, 0, 1, 2)
        gfx.addWidget(self.fx_porta, 2, 0, 1, 2)
        gfx.addWidget(self.fx_arp, 3, 0, 1, 2)
        gfx.addWidget(self.fx_vol, 4, 0, 1, 2)
        gfx.addWidget(self.fx_cut, 5, 0, 1, 2)
        gfx.addWidget(self.fx_retrig, 6, 0, 1, 2)
        gfx.addWidget(QLabel(self.i18n.tr("Intensity")), 7, 0)
        self.fx_intensity = QSlider(Qt.Orientation.Horizontal)
        self.fx_intensity.setRange(0, 100)
        self.fx_intensity.setValue(50)
        gfx.addWidget(self.fx_intensity, 7, 1)
        layout.addWidget(grp_fx)

        # tooltips for FX
        self.fx_init.setToolTip(self.i18n.tt("Insert initial speed/tempo"))
        self.fx_vib.setToolTip(self.i18n.tt("Vibrato on melody"))
        self.fx_porta.setToolTip(self.i18n.tt("Portamento transitions"))
        self.fx_arp.setToolTip(self.i18n.tt("Arpeggio ornaments"))
        self.fx_vol.setToolTip(self.i18n.tt("Volume motion"))
        self.fx_cut.setToolTip(self.i18n.tt("Note cut"))
        self.fx_retrig.setToolTip(self.i18n.tt("Retrig"))
        grp_fx.setToolTip(self.i18n.tt("FX Injection"))

        layout.addStretch(1)

    # ---------- language ----------
    def _on_lang_change(self, lang: str):
        self.i18n = I18N(lang)
        self._apply_language()

    def _apply_language(self):
        # For simplicity, only refresh a subset of visible labels.
        # (Full Qt translations can be added later.)
        self.btn_gen.setText(self.i18n.tr("GENERATE"))
        self.btn_regen.setText(self.i18n.tr("RE-GENERATE"))
        self.btn_play.setText(self.i18n.tr("PLAY"))
        self.btn_stop.setText(self.i18n.tr("STOP"))
        self.btn_open_out.setText(self.i18n.tr("OPEN OUTPUT"))
        self.btn_open_plg.setText(self.i18n.tr("OPEN PLUGINS"))
        self.btn_refresh.setText(self.i18n.tr("REFRESH"))
        self.btn_add_plg.setText(self.i18n.tr("ADD AS PLUGIN"))

    # ---------- helpers ----------
    def _append_log(self, s: str):
        self.log_text.append(str(s).rstrip())

    def _set_status(self, s: str):
        self.status_label.setText(s if (s and s.strip()) else "thinking...")
        self.render_lbl.setText(self.status_label.text())
        # Update title according to visualizer mode
        mode = getattr(self.visualizer, 'mode', 'spectrum')
        if mode == 'scope':
            self.viz_title.setText(self.i18n.tr("STEREO SCOPES"))
        elif mode == 'lightorgan':
            self.viz_title.setText(self.i18n.tr("LIGHT ORGAN"))
        else:
            self.viz_title.setText(self.i18n.tr("SPECTRUM ANALYZER"))

    def _set_progress(self, p: int):
        self.progress_bar.setValue(int(max(0, min(100, p))))

    def _smart_order(self):
        try:
            seed = int(self.seed_edit.text().strip() or backend.random_seed_value())
        except Exception:
            seed = int(backend.random_seed_value())
        rr = random.Random(seed ^ 0xA5A5)
        order = backend.generate_smart_order(rr, n_patterns=int(getattr(backend,'PATTERN_COUNT',20)))
        self.order_combo.setCurrentText(", ".join(str(x) for x in order))
        self.chk_use_smart.setChecked(True)

    def _random_key(self):
        try:
            self.key_edit.setText(backend.random_key_root())
        except Exception:
            self.key_edit.setText("C-2")

    def _random_seed(self):
        try:
            self.seed_edit.setText(str(backend.random_seed_value()))
        except Exception:
            self.seed_edit.setText(str(int(time.time()*1000)))

    def _randomize_instruments(self):
        palettes = [
            ["Piano", "Piano", "Piano", "Piano"],
            ["Piano", "Strings", "Choir Aah", "Organ"],
            ["Electric Piano", "Synth Pad", "Strings", "Choir Ooh"],
            ["Organ", "Choir Aah", "French Horn", "Bassoon"],
            ["Harp", "Strings", "Choir Ooh", "Flute"],
            ["Synth Pad", "Synth Lead", "Square Lead", "Bassoon"],
            ["Clarinet", "Sax", "French Horn", "Tuba"],
        ]
        try:
            st = self.seed_edit.text().strip()
            rr = random.Random(int(st) if st else int(time.time()*1000))
        except Exception:
            rr = random.Random(int(time.time()*1000))
        pal = rr.choice(palettes)
        for i in range(4):
            self.inst[i].setCurrentText(pal[i])

    def _open_output(self):
        try:
            open_folder(Path(self.cfg.out_dir))
        except Exception:
            open_folder(Path("mods_out"))

    def _open_plugins(self):
        open_folder(plugin_root())

    def _reload_melodies(self, initial: bool = False):
        names = reload_plugins()
        # Keep old selection
        prev = self.melody_combo.currentText() if hasattr(self, 'melody_combo') else ""
        if hasattr(self, 'melody_combo'):
            self.melody_combo.blockSignals(True)
            self.melody_combo.clear()
            # Ensure two canonical options
            self.melody_combo.addItem("Pure Random")
            self.melody_combo.addItem("Random")
            for n in names:
                if n in ("Pure Random", "Random"):
                    continue
                self.melody_combo.addItem(n)
            # restore
            if prev:
                self.melody_combo.setCurrentText(prev)
            elif initial:
                # Default to true random selection on first start
                self.melody_combo.setCurrentText("Random")
            self.melody_combo.blockSignals(False)
        if not initial:
            self._append_log(f"Reloaded {len(names)} melody plugin(s).")

    def _add_as_plugin(self):
        if self.last_song is None:
            self._append_log("No song yet.")
            return
        dest = add_last_as_plugin(self.last_mod_path, self.last_song, log_cb=self._append_log)
        if dest:
            self.btn_add_plg.setEnabled(True)

    # ---------- generation / playback ----------
    def _collect_cfg(self) -> SongConfig:
        cfg = SongConfig()

        cfg.out_dir = self.cfg.out_dir  # keep current unless we add picker later

        # seed
        seed_txt = self.seed_edit.text().strip()
        cfg.seed = int(seed_txt) if seed_txt else None
        cfg.auto_seed_each_generate = bool(self.chk_auto_seed.isChecked())
        cfg.batch_count = int(self.batch.value())

        # order
        cfg.order_str = self.order_combo.currentText()
        cfg.use_smart_order = bool(self.chk_use_smart.isChecked())

        # melody / derive / key
        m = self.melody_combo.currentText()
        if m in ("Random", ""):
            cfg.melody_name = None
        elif m == "Pure Random":
            cfg.melody_name = "Pure Random"
        else:
            cfg.melody_name = m
        cfg.derive_mode = self.derive_combo.currentText()
        k = self.key_edit.text().strip()
        cfg.key_root_override = k if k else None

        # melody influence window (rows)
        try:
            cfg.melody_influence_rows = int(self._influence_values[int(self.inf_slider.value())])
        except Exception:
            cfg.melody_influence_rows = 64

        # speed/tempo
        cfg.speed = int(self.speed.value())
        cfg.tempo = int(self.tempo.value())

        cfg.scale_mode = self.scale_combo.currentText()
        cfg.variation_pct = int(self.var_slider.value())
        cfg.stereo_width_pct = int(self.stereo_slider.value())

        cfg.mute_channels = [cb.isChecked() for cb in self.mute]
        cfg.quality_passes = int(self.passes.currentText())

        cfg.instruments = [c.currentText() for c in self.inst]
        cfg.octave_spans = [int(c.currentText()) for c in self.octv]

        # options tab
        cfg.export_wav = bool(self.opt_export_wav.isChecked())
        cfg.save_params = bool(self.opt_save_params.isChecked())
        cfg.disable_vibrato = bool(self.opt_disable_vibrato.isChecked())
        cfg.fadeout_pattern = bool(self.opt_fadeout.isChecked())
        cfg.enable_slowdown = bool(self.opt_slowdown.isChecked())

        cfg.pt2_compat_mode = bool(self.opt_compat.isChecked())
        cfg.compat_mode = bool(self.opt_compat.isChecked())
        sig = self.opt_sig.currentData()
        cfg.mod_signature = str(sig) if sig else (self.opt_sig.currentText().strip()[:4] if self.opt_sig.currentText() else None)

        cfg.ralph_loop = bool(self.opt_ralph.isChecked())
        cfg.ralph_target_score = float(self.opt_r_target.value())
        cfg.ralph_max_attempts = int(self.opt_r_attempts.value())
        cfg.ralph_ignore_drumsets = bool(getattr(self, 'opt_r_ignore_drums', None).isChecked()) if hasattr(self, 'opt_r_ignore_drums') else True

        cfg.fx_insert_initial_speed_tempo = bool(self.fx_init.isChecked())
        cfg.fx_vibrato_melody = bool(self.fx_vib.isChecked())
        cfg.fx_portamento_melody = bool(self.fx_porta.isChecked())
        cfg.fx_arpeggio_ornaments = bool(self.fx_arp.isChecked())
        cfg.fx_volume_motion = bool(self.fx_vol.isChecked())
        cfg.fx_note_cut = bool(self.fx_cut.isChecked())
        cfg.fx_retrig = bool(self.fx_retrig.isChecked())
        cfg.fx_intensity = int(self.fx_intensity.value())

        return cfg

    def _on_generate(self):
        if self.worker and self.worker.isRunning():
            return
        self.cfg = self._collect_cfg()

        self.btn_gen.setEnabled(False)
        self.btn_regen.setEnabled(False)
        self.btn_play.setEnabled(False)
        self.btn_stop.setEnabled(True)

        self.worker = GenerationWorker(self.cfg)
        self.worker.status.connect(self._set_status)
        self.worker.progress.connect(self._set_progress)
        self.worker.log.connect(self._append_log)
        self.worker.song_ready.connect(self._on_song_ready)
        self.worker.preview_ready.connect(self._on_preview_ready)
        self.worker.finished.connect(self._on_worker_done)
        self.worker.start()

    def _on_regenerate(self):
        # Force a new seed unless auto_seed is off (then increment)
        try:
            if self.chk_auto_seed.isChecked():
                self.seed_edit.setText(str(backend.random_seed_value()))
            else:
                cur = int(self.seed_edit.text().strip() or backend.random_seed_value())
                self.seed_edit.setText(str(cur + 1))
        except Exception:
            self.seed_edit.setText(str(int(time.time()*1000)))
        self._on_generate()

    def _on_song_ready(self, mod_path: Path, song: Any, q: Any):
        self.last_mod_path = Path(mod_path)
        self.last_song = song
        self.last_quality = q
        self.btn_regen.setEnabled(True)
        self.btn_add_plg.setEnabled(True)

        # Harmony label
        try:
            hs = float(getattr(q, 'harmony_score', getattr(song, 'harmony_score', 0.0)))
            self.harmony_lbl.setText(f"Harmony: {hs:.1f}%")
        except Exception:
            self.harmony_lbl.setText("Harmony: --%")

        # Populate pattern selector
        try:
            n = len(song.patterns)
            self.pattern_sel.blockSignals(True)
            self.pattern_sel.clear()
            for i in range(n):
                self.pattern_sel.addItem(str(i))
            self.pattern_sel.setCurrentText("0")
            self.pattern_sel.blockSignals(False)
            self._update_pattern_preview()
        except Exception:
            pass

        self._refresh_sample_display()

    def _on_preview_ready(self, wavb: bytes, pcm16: bytes, sr: int):
        self.preview_wav = wavb
        self.preview_pcm16 = pcm16
        self.preview_sr = int(sr)
        self.visualizer.set_audio(self.preview_pcm16, sr=self.preview_sr)
        self.btn_play.setEnabled(True)

        # Studio autosave-to-library hook (runs per variant, after WAV preview is available)
        try:
            if bool(getattr(self, "_studio_mode", False)) and bool(getattr(self, "_studio_autosave_library", False)):
                if self.last_mod_path and self.last_mod_path.exists():
                    wav_path = self.last_mod_path.with_suffix('.wav')
                    if not wav_path.exists() and self.preview_wav:
                        try:
                            wav_path.write_bytes(self.preview_wav)
                        except Exception:
                            wav_path = None
                    cfg_now = self._collect_cfg()
                    add_to_library(self.last_mod_path, cfg_now, quality=self.last_quality,
                                   wav_path=wav_path if wav_path and wav_path.exists() else None,
                                   tags=["studio", "batch"], log_cb=self._append_log)
                    try:
                        self.studio_log.appendPlainText(f"[library] saved {self.last_mod_path.name}")
                    except Exception:
                        pass
        except Exception:
            pass

    def _on_worker_done(self):
        self.btn_gen.setEnabled(True)
        self.btn_regen.setEnabled(True if self.last_song is not None else False)
        # STOP availability is managed by playback poller
        if self.preview_wav:
            self.btn_play.setEnabled(True)
        self._set_status("ready")
        self._set_progress(100)

        # Reset Studio mode
        try:
            if bool(getattr(self, "_studio_mode", False)):
                self._studio_mode = False
                self._studio_autosave_library = False
                try:
                    self._refresh_library()
                except Exception:
                    pass
        except Exception:
            pass

    def _on_play(self):
        if not self.preview_wav:
            return
        try:
            self.playback.play_wav_bytes(self.preview_wav)
            self._set_status("playing")
            # UI state (STOP usable during playback)
            self.btn_stop.setEnabled(True)
            self.btn_play.setEnabled(False)
        except Exception as e:
            self._append_log(f"[play] {e}")

    def _on_stop(self):
        # Stop playback
        try:
            self.playback.stop()
        except Exception:
            pass

        # Cancel generation if running
        if self.worker and self.worker.isRunning():
            try:
                self.worker.request_cancel()
            except Exception:
                pass

        # Update UI state
        self._set_status("ready")
        if self.preview_wav:
            self.btn_play.setEnabled(True)
        # STOP should only remain enabled if generation is still running
        self.btn_stop.setEnabled(bool(self.worker and self.worker.isRunning()))

    
    def _on_order_user_edit(self, _txt: str):
        # User typed into the order field -> don't auto-override with presets.
        self._order_user_modified = True

    def _on_melody_selected(self, name: str):
        try:
            if not name or name in ("Random", "Pure Random"):
                return
            if bool(self.chk_use_smart.isChecked()):
                return
            rec = get_recommended_pattern_order(name)
            if rec:
                rec = rec.replace(";", ",").strip()
            else:
                rec = None
            cur = (self.order_combo.currentText() or "").strip()
            default = str(getattr(backend, 'DEFAULT_ORDER_STR', '0,1,2,3,4,5')).strip()
            # Apply only if user didn't edit, or order is still default/empty, or it matches previous auto order
            if rec and ((not self._order_user_modified) or (not cur) or (cur == default) or (self._last_auto_order and cur == self._last_auto_order)):
                self.order_combo.setCurrentText(rec)
                self._last_auto_order = rec
                self._order_user_modified = False

            # Also allow plugins (Hijack MIDI imports) to suggest a motif influence window.
            try:
                meta = get_plugin_meta(name)
                mr = meta.get('motif_rows', '')
                if mr and not getattr(self, '_motif_user_modified', False):
                    try:
                        v = int(str(mr).strip())
                        if v in getattr(self, '_influence_values', [8,16,32,64]):
                            self.inf_slider.setValue(getattr(self, '_influence_values', [8,16,32,64]).index(v))
                            self._append_log(f"[preset] {name}: motif rows set to {v}")
                    except Exception:
                        pass
                mode = meta.get('mode', '')
                if rec:
                    if mode:
                        self._append_log(f"[preset] {name}: applied suggested pattern order (mode={mode})")
                    else:
                        self._append_log(f"[preset] {name}: applied suggested pattern order")
            except Exception:
                pass
        except Exception:
            pass

# ---------- pattern preview ----------
    def _update_pattern_preview(self):
        if self.last_song is None:
            self.pattern_text.setPlainText("")
            return
        try:
            idx = int(self.pattern_sel.currentText())
        except Exception:
            idx = 0
        try:
            pat = self.last_song.patterns[idx]
        except Exception:
            self.pattern_text.setPlainText("")
            return
        try:
            order = list(getattr(self.last_song, 'order', []) or getattr(self.last_song, 'order_original', []) or [])
            poss = order_positions_for_pattern(order, idx)
        except Exception:
            poss = []
        self.pattern_text.setPlainText(format_pattern(pat, idx, poss))

    # ---------- samples ----------

    def _tab_hijack(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        title = QLabel(self.i18n.tr("Hijack"))
        try:
            title.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        except Exception:
            pass
        layout.addWidget(title)

        # MIDI file picker
        row1 = QHBoxLayout()
        row1.addWidget(QLabel(self.i18n.tr("MIDI file")))
        self.hj_path = QLineEdit()
        btn_browse = QPushButton(self.i18n.tr("Browse"))
        def _browse():
            try:
                from PyQt6.QtWidgets import QFileDialog
                p, _ = QFileDialog.getOpenFileName(self, self.i18n.tr("MIDI file"), str(Path.cwd()), "MIDI (*.mid *.midi)")
                if p:
                    self.hj_path.setText(p)
                    if not self.hj_name.text().strip():
                        self.hj_name.setText(Path(p).stem)
            except Exception as e:
                self._append_log(f"[hijack] browse failed: {e}")
        btn_browse.clicked.connect(_browse)

        row1.addWidget(self.hj_path, 1)
        row1.addWidget(btn_browse)
        layout.addLayout(row1)

        # Plugin name
        row2 = QHBoxLayout()
        row2.addWidget(QLabel(self.i18n.tr("Plugin name")))
        self.hj_name = QLineEdit()
        row2.addWidget(self.hj_name, 1)
        layout.addLayout(row2)

        # Mode hint + options
        row3 = QHBoxLayout()
        row3.addWidget(QLabel(self.i18n.tr("Mode hint")))
        self.hj_mode = QComboBox()
        self.hj_mode.addItems(["", "major", "minor", "mixed", "dorian", "mixolydian"])
        row3.addWidget(self.hj_mode)

        row3.addWidget(QLabel(self.i18n.tr("Motif rows")))
        self.hj_rows = QComboBox()
        self.hj_rows.addItems(["8", "16", "32", "64", self.i18n.tr("Full song")])
        self.hj_rows.setCurrentText("64")
        row3.addWidget(self.hj_rows)

        row3.addWidget(QLabel(self.i18n.tr("Window mode")))
        self.hj_window_mode = QComboBox()
        # random: pick a different 4-bar window each render
        # sequential: walk through the MIDI in 4-bar blocks across patterns
        # start0: always start at beginning
        self.hj_window_mode.addItems([
            self.i18n.tr("Random window"),
            self.i18n.tr("Sequential"),
            self.i18n.tr("Start at beginning"),
        ])
        self.hj_window_mode.setCurrentIndex(0)
        row3.addWidget(self.hj_window_mode)

        def _hj_rows_changed(_t: str):
            # If user selects "Full song", force sequential mode.
            try:
                is_full = (self.hj_rows.currentText().strip().lower() == self.i18n.tr("Full song").lower())
            except Exception:
                is_full = False
            if is_full:
                self.hj_window_mode.setCurrentText(self.i18n.tr("Sequential"))
                self.hj_window_mode.setEnabled(False)
            else:
                self.hj_window_mode.setEnabled(True)

        self.hj_rows.currentTextChanged.connect(_hj_rows_changed)
        _hj_rows_changed(self.hj_rows.currentText())
        row3.addStretch(1)
        layout.addLayout(row3)

        # Import button
        btn_row = QHBoxLayout()
        self.btn_hj_import = QPushButton(self.i18n.tr("Import MIDI as plugin"))
        self.btn_hj_import.clicked.connect(self._hijack_import_midi)
        btn_row.addWidget(self.btn_hj_import)
        btn_row.addStretch(1)
        layout.addLayout(btn_row)

        info = QLabel(
            "Imports a MIDI file into the melody_plugins folder as a plugin.\n"
            "Motif rows controls how strongly the imported melody influences the generated song.\n"
            "Window mode controls how long MIDI songs are used (random vs sequential vs start0)."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        layout.addStretch(1)
        self.tabs.addTab(tab, self.i18n.tr("Hijack"))

    def _hijack_import_midi(self):
        try:
            midi_p = Path(self.hj_path.text().strip())
            nm = self.hj_name.text().strip() or midi_p.stem
            mode = self.hj_mode.currentText().strip()
            # Hijack import options
            rows_txt = self.hj_rows.currentText().strip() if hasattr(self, 'hj_rows') else '64'
            is_full = (rows_txt.lower() == self.i18n.tr('Full song').lower())
            try:
                motif_rows = 64 if is_full else int(rows_txt)
            except Exception:
                motif_rows = 64
            wm_label = self.hj_window_mode.currentText().strip() if hasattr(self, 'hj_window_mode') else self.i18n.tr('Random window')
            if wm_label == self.i18n.tr('Sequential'):
                window_mode = 'sequential'
            elif wm_label == self.i18n.tr('Start at beginning'):
                window_mode = 'start0'
            else:
                window_mode = 'random'
            if is_full:
                window_mode = 'sequential'
            full_song = True if is_full else True
            if not midi_p.exists():
                self._append_log(f"[hijack] MIDI not found: {midi_p}")
                return
            dest = import_midi_as_plugin(
                midi_p,
                nm,
                mode_hint=mode,
                full_song=full_song,
                motif_rows=motif_rows,
                window_mode=window_mode,
                log_cb=self._append_log,
            )
            if not dest:
                return
            # Refresh melody list and select new plugin if possible
            self._reload_melodies()
            # Try selecting by name
            for i in range(self.melody_combo.count()):
                if self.melody_combo.itemText(i).strip() == nm:
                    self.melody_combo.setCurrentIndex(i)
                    break
            self._append_log(f"[hijack] Imported: {nm}")
        except Exception as e:
            self._append_log(f"[hijack] import failed: {e}")


    # ---------- FUTURE EDITION TABS (2031 snapshot) ----------
    def _tab_studio(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        title = QLabel("STUDIO (Batch, A/B, Library Pipeline)")
        title.setStyleSheet("font-size: 18px; font-weight: 600;")
        layout.addWidget(title)

        grp = QGroupBox("Batch generator")
        g = QGridLayout(grp)

        g.addWidget(QLabel("Variants"), 0, 0)
        self.st_batch_n = QSpinBox(); self.st_batch_n.setRange(1, 100); self.st_batch_n.setValue(8)
        g.addWidget(self.st_batch_n, 0, 1)

        self.st_seed_random = QCheckBox("Random seed for each variant")
        self.st_seed_random.setChecked(True)
        g.addWidget(self.st_seed_random, 1, 0, 1, 2)

        self.st_use_ralph = QCheckBox("Use Ralph-Loop for each variant")
        self.st_use_ralph.setChecked(True)
        g.addWidget(self.st_use_ralph, 2, 0, 1, 2)

        self.st_export_wav = QCheckBox("Export WAV for each variant")
        self.st_export_wav.setChecked(True)
        g.addWidget(self.st_export_wav, 3, 0, 1, 2)

        self.st_autosave_library = QCheckBox("Auto-save each variant to Library")
        self.st_autosave_library.setChecked(True)
        g.addWidget(self.st_autosave_library, 4, 0, 1, 2)

        self.btn_studio_go = QPushButton("GENERATE BATCH")
        self.btn_studio_go.clicked.connect(self._on_studio_generate)
        g.addWidget(self.btn_studio_go, 5, 0, 1, 2)

        layout.addWidget(grp)

        info = QLabel(
            "This is the 2031-style workflow: generate many variants, keep the best,\n"
            "and build a personal tracker library (with WAV previews + ratings)."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        self.studio_log = QPlainTextEdit(); self.studio_log.setReadOnly(True)
        self.studio_log.setPlaceholderText("Studio log…")
        layout.addWidget(self.studio_log, 1)

        self.tabs.addTab(tab, "STUDIO")

    def _on_studio_generate(self):
        """Run a batch using the existing generator worker, but with Studio overrides."""
        try:
            # Set overrides into the main config UI so everything stays consistent
            self.batch.setValue(int(self.st_batch_n.value()))
            self.chk_auto_seed.setChecked(bool(self.st_seed_random.isChecked()))
            self.opt_r_enable.setChecked(bool(self.st_use_ralph.isChecked()))
            self.opt_export_wav.setChecked(bool(self.st_export_wav.isChecked()))
            self._studio_mode = True
            self._studio_autosave_library = bool(self.st_autosave_library.isChecked())
            self.studio_log.appendPlainText(f"[studio] batch={self.batch.value()}  auto_seed={self.chk_auto_seed.isChecked()}  ralph={self.opt_r_enable.isChecked()}  wav={self.opt_export_wav.isChecked()}  autosave={self._studio_autosave_library}")
            self._on_generate()
        except Exception as e:
            self._append_log(f"[studio] failed: {e}")

    def _tab_library(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        title = QLabel("LIBRARY (Personal MOD vault)")
        title.setStyleSheet("font-size: 18px; font-weight: 600;")
        layout.addWidget(title)

        row = QHBoxLayout()
        self.btn_lib_refresh = QPushButton("Refresh")
        self.btn_lib_refresh.clicked.connect(self._refresh_library)
        self.btn_lib_add_current = QPushButton("Add current song to Library")
        self.btn_lib_add_current.clicked.connect(self._add_current_to_library)
        row.addWidget(self.btn_lib_refresh)
        row.addWidget(self.btn_lib_add_current)
        row.addStretch(1)
        layout.addLayout(row)

        mid = QHBoxLayout()
        self.lib_list = QListWidget()
        self.lib_list.currentItemChanged.connect(self._on_library_selection)
        mid.addWidget(self.lib_list, 1)

        right = QVBoxLayout()
        self.lib_meta = QPlainTextEdit(); self.lib_meta.setReadOnly(True)
        right.addWidget(self.lib_meta, 1)

        btns = QHBoxLayout()
        self.btn_lib_play = QPushButton("Play WAV")
        self.btn_lib_play.clicked.connect(self._library_play)
        self.btn_lib_open = QPushButton("Open folder")
        self.btn_lib_open.clicked.connect(self._library_open_folder)
        btns.addWidget(self.btn_lib_play)
        btns.addWidget(self.btn_lib_open)
        right.addLayout(btns)

        rate_row = QHBoxLayout()
        rate_row.addWidget(QLabel("Rating"))
        self.lib_rating = QSpinBox(); self.lib_rating.setRange(0, 10); self.lib_rating.setValue(0)
        self.btn_lib_set_rating = QPushButton("Set")
        self.btn_lib_set_rating.clicked.connect(self._library_set_rating)
        rate_row.addWidget(self.lib_rating)
        rate_row.addWidget(self.btn_lib_set_rating)
        rate_row.addStretch(1)
        right.addLayout(rate_row)

        right_wrap = QWidget(); right_wrap.setLayout(right)
        mid.addWidget(right_wrap, 2)

        layout.addLayout(mid, 1)

        self.tabs.addTab(tab, "LIBRARY")
        self._refresh_library()

    def _refresh_library(self):
        try:
            self.lib_list.clear()
            entries = scan_library(getattr(self.cfg, 'out_dir', None))
            self._lib_entries = entries
            for e in entries:
                title = e.get('title') or 'untitled'
                rating = e.get('rating')
                s = f"{title}"
                if rating is not None:
                    s += f"  [★{rating}]"
                it = QListWidgetItem(s)
                # store item directory name (reconstruct path)
                seed = e.get('seed')
                created = e.get('created_at')
                # meta.json contains enough to locate the folder by scanning; easiest: stash index
                it.setData(Qt.ItemDataRole.UserRole, e)
                self.lib_list.addItem(it)
            if self.lib_list.count() > 0:
                self.lib_list.setCurrentRow(0)
        except Exception as ex:
            self._append_log(f"[library] refresh failed: {ex}")

    def _on_library_selection(self, cur: QListWidgetItem, _prev: QListWidgetItem):
        try:
            if not cur:
                self.lib_meta.setPlainText("")
                return
            e = cur.data(Qt.ItemDataRole.UserRole) or {}
            self.lib_meta.setPlainText(str(e).replace(', ', ',\n'))
            r = e.get('rating')
            self.lib_rating.setValue(int(r) if r is not None else 0)
        except Exception:
            pass

    def _library_item_dir(self, entry: dict) -> Path | None:
        try:
            lib = library_root(getattr(self.cfg, 'out_dir', None))
            items = lib / 'items'
            # find by created_at + seed + title prefix
            created = entry.get('created_at')
            seed = entry.get('seed')
            title = entry.get('title')
            if not created or title is None:
                return None
            # best effort match
            prefix = f"{created}__{seed if seed is not None else 'noseed'}__{title}"
            cand = items / prefix
            if cand.exists():
                return cand
            # fallback: scan
            for d in items.glob(f"{created}__*__{title}*"):
                if d.is_dir():
                    return d
        except Exception:
            return None
        return None

    def _library_play(self):
        try:
            it = self.lib_list.currentItem()
            if not it:
                return
            e = it.data(Qt.ItemDataRole.UserRole) or {}
            d = self._library_item_dir(e)
            if not d:
                return
            wav = e.get('wav_file')
            if not wav:
                QMessageBox.information(self, "No WAV", "This entry has no WAV preview. Generate with WAV export enabled.")
                return
            wp = d / str(wav)
            if not wp.exists():
                QMessageBox.information(self, "Missing WAV", f"File not found: {wp}")
                return
            self.playback.play_wav_bytes(wp.read_bytes())
            self._set_status("playing")
        except Exception as ex:
            self._append_log(f"[library] play failed: {ex}")

    def _library_open_folder(self):
        try:
            it = self.lib_list.currentItem()
            if not it:
                return
            e = it.data(Qt.ItemDataRole.UserRole) or {}
            d = self._library_item_dir(e)
            if d:
                open_folder(d)
        except Exception:
            pass

    def _library_set_rating(self):
        try:
            it = self.lib_list.currentItem()
            if not it:
                return
            e = it.data(Qt.ItemDataRole.UserRole) or {}
            d = self._library_item_dir(e)
            if not d:
                return
            r = int(self.lib_rating.value())
            update_rating(d, r, log_cb=self._append_log)
            self._refresh_library()
        except Exception as ex:
            self._append_log(f"[library] rating failed: {ex}")

    def _add_current_to_library(self):
        try:
            if not self.last_mod_path or not self.last_mod_path.exists():
                QMessageBox.information(self, "No song", "Generate a song first.")
                return
            # Ensure we have a WAV preview (either exported or current preview buffer)
            wav_path = self.last_mod_path.with_suffix('.wav')
            if not wav_path.exists() and getattr(self, 'preview_wav', None):
                try:
                    wav_path.write_bytes(self.preview_wav)
                except Exception:
                    wav_path = None
            cfg_now = self._collect_cfg()
            add_to_library(self.last_mod_path, cfg_now, quality=self.last_quality, wav_path=wav_path if wav_path and wav_path.exists() else None, tags=["manual"], log_cb=self._append_log)
            self._refresh_library()
        except Exception as ex:
            self._append_log(f"[library] add current failed: {ex}")

    def _tab_export(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        title = QLabel("EXPORT (Presets, Packages)")
        title.setStyleSheet("font-size: 18px; font-weight: 600;")
        layout.addWidget(title)

        grp = QGroupBox("Preset files")
        g = QGridLayout(grp)
        g.addWidget(QLabel("Preset name"), 0, 0)
        self.preset_name = QLineEdit("my_preset")
        g.addWidget(self.preset_name, 0, 1)
        self.btn_preset_save = QPushButton("Save preset")
        self.btn_preset_save.clicked.connect(self._preset_save)
        g.addWidget(self.btn_preset_save, 1, 0)
        self.btn_preset_load = QPushButton("Load preset")
        self.btn_preset_load.clicked.connect(self._preset_load)
        g.addWidget(self.btn_preset_load, 1, 1)
        layout.addWidget(grp)

        self.export_info = QPlainTextEdit(); self.export_info.setReadOnly(True)
        self.export_info.setPlainText(
            "Future Edition export philosophy:\n"
            "- presets are plain JSON (ptmgpreset.json)\n"
            "- library items are self-contained folders\n"
            "- plugins are folder-based (melody.txt / melody.mid + meta)\n"
        )
        layout.addWidget(self.export_info, 1)

        self.tabs.addTab(tab, "EXPORT")

    def _preset_save(self):
        try:
            cfg_now = self._collect_cfg()
            name = self.preset_name.text().strip() or "preset"
            path = save_preset(cfg_now, name, base_out_dir=cfg_now.out_dir)
            self._append_log(f"[preset] saved: {path}")
        except Exception as ex:
            self._append_log(f"[preset] save failed: {ex}")

    def _preset_load(self):
        try:
            base = presets_root(getattr(self.cfg, 'out_dir', None))
            path, _ = QFileDialog.getOpenFileName(self, "Load preset", str(base), "Preset (*.ptmgpreset.json);;JSON (*.json);;All files (*.*)")
            if not path:
                return
            d = load_preset(Path(path))
            self._apply_preset_dict(d)
            self._append_log(f"[preset] loaded: {Path(path).name}")
        except Exception as ex:
            self._append_log(f"[preset] load failed: {ex}")

    def _apply_preset_dict(self, d: dict):
        """Best-effort apply a saved preset dict onto current UI widgets."""
        try:
            if 'seed' in d and d['seed'] is not None:
                self.seed_edit.setText(str(d['seed']))
            if 'tempo' in d:
                self.tempo.setValue(int(d['tempo']))
            if 'speed' in d:
                self.speed.setValue(int(d['speed']))
            if 'variation_pct' in d:
                self.variation.setValue(int(d['variation_pct']))
            if 'stereo_width_pct' in d:
                self.stereo.setValue(int(d['stereo_width_pct']))
            if 'batch_count' in d:
                self.batch.setValue(int(d['batch_count']))
            if 'order_str' in d and d['order_str']:
                self.order_combo.setCurrentText(str(d['order_str']))
            if 'use_smart_order' in d:
                self.chk_use_smart.setChecked(bool(d['use_smart_order']))
            if 'melody_name' in d:
                # try select
                nm = d['melody_name'] or 'Random'
                for i in range(self.melody_combo.count()):
                    if self.melody_combo.itemText(i).strip() == str(nm):
                        self.melody_combo.setCurrentIndex(i)
                        break
            if 'derive_mode' in d:
                self.derive_combo.setCurrentText(str(d['derive_mode']))
            if 'key_root_override' in d:
                self.key_edit.setText(str(d['key_root_override'] or ''))
            if 'scale_mode' in d:
                self.scale_combo.setCurrentText(str(d['scale_mode']))
            if 'instruments' in d and isinstance(d['instruments'], list):
                for ch in range(min(4, len(d['instruments']))):
                    self.inst[ch].setCurrentText(str(d['instruments'][ch]))
            if 'octave_spans' in d and isinstance(d['octave_spans'], list):
                for ch in range(min(4, len(d['octave_spans']))):
                    self.oct_spins[ch].setValue(int(d['octave_spans'][ch]))
            if 'ralph_loop' in d:
                self.opt_r_enable.setChecked(bool(d['ralph_loop']))
            if 'ralph_target_score' in d:
                self.opt_r_target.setValue(int(d['ralph_target_score']))
            if 'ralph_max_attempts' in d:
                self.opt_r_attempts.setValue(int(d['ralph_max_attempts']))
            if 'pt2_compat_mode' in d:
                self.opt_compat.setChecked(bool(d['pt2_compat_mode']))
        except Exception:
            pass

    def _tab_docs(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        title = QLabel("DOCS (2031 retrospective)")
        title.setStyleSheet("font-size: 18px; font-weight: 600;")
        layout.addWidget(title)

        row = QHBoxLayout()
        btn_open_docs = QPushButton("Open docs folder")
        btn_open_docs.clicked.connect(lambda: open_folder(Path('docs').resolve()))
        btn_open_help = QPushButton("Open AmigaGuide viewer")
        btn_open_help.clicked.connect(self._open_help_viewer)
        row.addWidget(btn_open_docs)
        row.addWidget(btn_open_help)
        row.addStretch(1)
        layout.addLayout(row)

        p = Path('docs/FUTURE_TIMELINE.md')
        try:
            txt = p.read_text(encoding='utf-8') if p.exists() else "(missing FUTURE_TIMELINE.md)"
        except Exception:
            txt = "(failed to load FUTURE_TIMELINE.md)"
        box = QPlainTextEdit(); box.setReadOnly(True)
        box.setPlainText(txt)
        layout.addWidget(box, 1)
        self.tabs.addTab(tab, "DOCS")

    def _tab_lab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        title = QLabel("LAB (Experimental engines)")
        title.setStyleSheet("font-size: 18px; font-weight: 600;")
        layout.addWidget(title)

        info = QLabel(
            "This tab represents five years of feature-gating and controversy.\n"
            "Everything here is optional and safe to ignore; defaults are conservative."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        self.lab_novelty = QCheckBox("Novelty guard (avoid near-duplicates)")
        self.lab_novelty.setChecked(True)
        self.lab_microfx = QCheckBox("Micro-FX sprinkling (safe subset)")
        self.lab_microfx.setChecked(False)
        self.lab_struct = QCheckBox("Structure aware order (A/B/bridge)")
        self.lab_struct.setChecked(True)
        layout.addWidget(self.lab_novelty)
        layout.addWidget(self.lab_microfx)
        layout.addWidget(self.lab_struct)

        self.lab_notes = QPlainTextEdit(); self.lab_notes.setReadOnly(True)
        self.lab_notes.setPlainText(
            "Future note:\n"
            "- Novelty guard is currently UI-only (planned: n-gram melody distance).\n"
            "- Micro-FX can be mapped to FX Injection toggles.\n"
            "- Structure aware order already exists via SMART + presets."
        )
        layout.addWidget(self.lab_notes, 1)
        self.tabs.addTab(tab, "LAB")

    def _refresh_sample_display(self):
        if not hasattr(self, 'sample_rows'):
            return
        # show instruments + status (custom/generated) + base volume
        kinds = [c.currentText() for c in getattr(self, 'inst', [])] if hasattr(self, 'inst') else ["Piano"]*4
        for ch in range(4):
            row = self.sample_rows[ch]
            inst_kind = kinds[ch] if ch < len(kinds) else f"CH{ch+1}"
            row["inst"].setText(inst_kind)
            custom = self.cfg.custom_sample_paths.get(ch)
            row["status"].setText("Custom" if custom else "Generated")
            try:
                vol = int(getattr(backend, 'INSTRUMENT_VOL', {}).get(inst_kind, 48))
            except Exception:
                vol = 48
            row["vol"].setText(str(vol))
        self.samples_info.setPlainText(
            "Sample Manager\n\n"
            "- Generated: procedural instrument\n"
            "- Custom: user WAV\n\n"
            "Replace: set a custom WAV for this channel.\n"
            "Reset: remove custom WAV.\n"
            "Play: preview immediately (even without generating a song).\n"
        )

    def _play_sample(self, ch: int):
        # custom path first
        p = self.cfg.custom_sample_paths.get(ch)
        if p:
            wavb = self.sample_engine.preview_wav_from_custom_path(p)
            if wavb:
                self.playback.play_wav_bytes(wavb)
                self._append_log(f"Playing CH{ch+1} custom sample: {Path(p).name}")
                return

        # use current instrument selection (works without song)
        inst_kind = self.inst[ch].currentText() if ch < len(self.inst) else "Piano"
        is_drum = False
        drum_style = "Kick"
        try:
            st = backend.drumset_style_from_kind(inst_kind)
            if st:
                is_drum = True
                drum_style = "Kick"
        except Exception:
            pass

        spec = SamplePreviewSpec(
            instrument_kind=inst_kind,
            disable_vibrato=bool(self.opt_disable_vibrato.isChecked()),
            seed=(int(self.seed_edit.text().strip() or backend.random_seed_value()) ^ (ch*1337)),
            is_drum=is_drum,
            drum_style=drum_style,
        )
        try:
            wavb = self.sample_engine.preview_wav_for(spec)
            self.playback.play_wav_bytes(wavb)
            self._append_log(f"Playing CH{ch+1}: {inst_kind}")
        except Exception as e:
            self._append_log(f"Play sample error: {e}")

    def _replace_sample(self, ch: int):
        path, _ = QFileDialog.getOpenFileName(self, f"Import WAV for CH{ch+1}", "", "WAV files (*.wav);;All files (*.*)")
        if not path:
            return
        self.cfg.custom_sample_paths[int(ch)] = str(path)
        self._refresh_sample_display()
        self._append_log(f"CH{ch+1}: Imported custom sample: {Path(path).name}")

    def _reset_sample(self, ch: int):
        if int(ch) in self.cfg.custom_sample_paths:
            self.cfg.custom_sample_paths.pop(int(ch), None)
        self._refresh_sample_display()
        self._append_log(f"CH{ch+1}: Reset to generated sample")

    def _import_all_samples(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Import WAV files", "", "WAV files (*.wav);;All files (*.*)")
        if not paths:
            return
        for i, p in enumerate(paths[:4]):
            self.cfg.custom_sample_paths[int(i)] = str(p)
        self._refresh_sample_display()
        self._append_log(f"Imported {min(4,len(paths))} sample(s).")


    def _open_help_viewer(self) -> None:
        """
        Launch the standalone AmigaGuide-like viewer (separate process),
        starting at docs/ProtrackerMusicGenerator_Index.guide.
        """
        try:
            root = Path(__file__).resolve().parents[2]
            viewer = root / "guide_viewer_app.py"
            index = root / "docs" / "ProtrackerMusicGenerator_Index.guide"
            if not viewer.exists():
                self._append_log(f"[help] viewer script missing: {viewer}")
                return
            if not index.exists():
                self._append_log(f"[help] index missing: {index}")
                return
            subprocess.Popen([sys.executable, str(viewer), str(index)], cwd=str(root))
        except Exception as e:
            self._append_log(f"[help] failed to launch viewer: {e}")


    # ---------- compatibility ----------
    def _on_pt2_compat_toggled(self, checked: bool):
        """PT2 clone / ProTracker 2 is strict: force a canonical 4ch signature."""
        try:
            if checked:
                # Force to M.K. in UI and prevent user from selecting tags that PT2 won't accept.
                for i in range(self.opt_sig.count()):
                    if str(self.opt_sig.itemData(i)) == "M.K.":
                        self.opt_sig.setCurrentIndex(i)
                        break
                self.opt_sig.setEnabled(False)
            else:
                self.opt_sig.setEnabled(True)
        except Exception:
            pass


    # ---------- theme ----------
    def _apply_theme(self):
        name = self.theme_combo.currentText()
        th = self.themes.get(name)
        if th:
            self.apply_theme_cb(th)
            self._append_log(f"Theme applied: {name}")

    def _on_tab_changed(self, idx: int):
        # Keep Samples tab labels consistent even if user never touched instrument combobox after load
        try:
            self._refresh_sample_display()
        except Exception:
            pass

    def _poll_playback_state(self):
        """Keep UI buttons consistent while audio is playing (Qt or subprocess)."""
        try:
            playing = bool(self.playback.is_playing())
        except Exception:
            playing = False

        gen_running = bool(self.worker and self.worker.isRunning())

        # STOP is available if playing OR generating (worker running)
        self.btn_stop.setEnabled(bool(playing or gen_running))

        # PLAY enabled only when we have a preview and not currently playing
        if self.preview_wav:
            self.btn_play.setEnabled(not playing)
        else:
            self.btn_play.setEnabled(False)

        # Auto-switch status back to ready when playback ends
        try:
            was = bool(getattr(self, "_was_playing", False))
        except Exception:
            was = False
        if was and (not playing) and (not gen_running):
            self._set_status("ready")
        self._was_playing = playing

