from __future__ import annotations

import json
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable, Optional

from ptmod.config import SongConfig

LogCb = Optional[Callable[[str], None]]

def _cb(cb: LogCb, msg: str):
    try:
        if cb:
            cb(msg)
    except Exception:
        pass

def library_root(base_out_dir: str | None = None) -> Path:
    """Return the library root folder (created if missing)."""
    # Default: <project>/library
    p = Path(base_out_dir or ".").resolve()
    # If out_dir points to outputs, keep library sibling
    if p.name.lower() in ("outputs", "output", "out"):
        p = p.parent
    lib = p / "library"
    lib.mkdir(parents=True, exist_ok=True)
    (lib / "items").mkdir(parents=True, exist_ok=True)
    return lib

def _safe_slug(s: str) -> str:
    s = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in (s or ""))
    s = s.strip("_") or "untitled"
    return s[:80]

def add_to_library(mod_path: Path,
                   cfg: SongConfig,
                   quality: Any = None,
                   wav_path: Path | None = None,
                   tags: list[str] | None = None,
                   rating: int | None = None,
                   log_cb: LogCb = None) -> Path:
    """Copy artifacts into the library and write a metadata json sidecar.

    Returns the library item folder.
    """
    lib = library_root(cfg.out_dir)
    items = lib / "items"
    ts = time.strftime("%Y%m%d_%H%M%S")
    title = _safe_slug(getattr(cfg, "title", "") or mod_path.stem)
    seed = getattr(cfg, "seed", None)
    seed_s = str(seed) if seed is not None else "noseed"
    item_dir = items / f"{ts}__{seed_s}__{title}"
    item_dir.mkdir(parents=True, exist_ok=True)

    # Copy files
    mod_dst = item_dir / mod_path.name
    try:
        mod_dst.write_bytes(mod_path.read_bytes())
    except Exception as e:
        _cb(log_cb, f"[library] copy mod failed: {e}")

    wav_dst = None
    if wav_path and wav_path.exists():
        wav_dst = item_dir / wav_path.name
        try:
            wav_dst.write_bytes(wav_path.read_bytes())
        except Exception as e:
            _cb(log_cb, f"[library] copy wav failed: {e}")

    meta = {
        "created_at": ts,
        "title": title,
        "seed": seed,
        "mod_file": mod_dst.name if mod_dst.exists() else None,
        "wav_file": wav_dst.name if wav_dst and wav_dst.exists() else None,
        "tags": tags or [],
        "rating": rating,
        "cfg": asdict(cfg),
        "quality": None,
    }
    try:
        if quality is not None:
            # best-effort serialization
            if hasattr(quality, "__dict__"):
                meta["quality"] = dict(quality.__dict__)
            else:
                meta["quality"] = str(quality)
    except Exception:
        pass

    (item_dir / "meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    _cb(log_cb, f"[library] saved: {item_dir.name}")
    return item_dir

def scan_library(base_out_dir: str | None = None) -> list[dict[str, Any]]:
    lib = library_root(base_out_dir)
    items = lib / "items"
    out: list[dict[str, Any]] = []
    for d in sorted(items.glob("*"), reverse=True):
        if not d.is_dir():
            continue
        mp = d / "meta.json"
        if mp.exists():
            try:
                out.append(json.loads(mp.read_text(encoding="utf-8")))
            except Exception:
                continue
    return out

def update_rating(item_dir: Path, rating: int | None, log_cb: LogCb = None) -> None:
    mp = item_dir / "meta.json"
    if not mp.exists():
        return
    try:
        meta = json.loads(mp.read_text(encoding="utf-8"))
        meta["rating"] = None if rating is None else int(rating)
        mp.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
        _cb(log_cb, f"[library] rating updated: {item_dir.name} -> {meta['rating']}")
    except Exception as e:
        _cb(log_cb, f"[library] rating update failed: {e}")
