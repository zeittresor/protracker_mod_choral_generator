from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable, Optional

from ptmod.config import SongConfig
from ptmod.engines.generator_engine import generate_with_ralph_loop, generate_song_once
from ptmod.engines.library_engine import add_to_library

StatusCb = Optional[Callable[[str], None]]
ProgressCb = Optional[Callable[[int], None]]
LogCb = Optional[Callable[[str], None]]

def _cb(cb, *args):
    try:
        if cb:
            cb(*args)
    except Exception:
        pass

def generate_batch(cfg: SongConfig,
                   n: int,
                   use_ralph: bool = True,
                   seed_mode: str = "spread",
                   save_to_library: bool = True,
                   status_cb: StatusCb = None,
                   progress_cb: ProgressCb = None,
                   log_cb: LogCb = None) -> list[Path]:
    """Generate N variants, optionally Ralph-looping each.

    seed_mode:
      - spread: xor-spread seeds
      - increment: seed+idx
      - random: random_seed each time
    """
    n = max(1, int(n))
    paths: list[Path] = []
    base_seed = int(cfg.seed or 0)

    for i in range(n):
        # copy cfg
        local = SongConfig(**asdict(cfg))
        if seed_mode == "increment":
            local.seed = base_seed + i
        elif seed_mode == "random":
            local.seed = None
        else:
            local.seed = (base_seed ^ (i * 0x9E3779B1) ^ ((i + 7) * 0x85EBCA6B)) & 0xFFFFFFFF

        _cb(status_cb, f"batch {i+1}/{n}")
        _cb(progress_cb, int((i / n) * 100))

        if use_ralph:
            p, song, q = generate_with_ralph_loop(local, status_cb=None, progress_cb=None, log_cb=log_cb)
        else:
            p, song, q = generate_song_once(local, status_cb=None, progress_cb=None, log_cb=log_cb)

        paths.append(Path(p))

        if save_to_library:
            try:
                # If export_wav enabled, song might already have preview wav in cfg.out_dir; we don't rely on it here.
                add_to_library(Path(p), local, quality=q, wav_path=None, tags=["batch"], rating=None, log_cb=log_cb)
            except Exception as e:
                _cb(log_cb, f"[batch] library save failed: {e}")

    _cb(progress_cb, 100)
    _cb(status_cb, "ready")
    return paths
