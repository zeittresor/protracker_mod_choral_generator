from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

from ptmod.config import SongConfig

def presets_root(base_out_dir: str | None = None) -> Path:
    p = Path(base_out_dir or ".").resolve()
    if p.name.lower() in ("outputs", "output", "out"):
        p = p.parent
    d = p / "presets"
    d.mkdir(parents=True, exist_ok=True)
    return d

def save_preset(cfg: SongConfig, name: str, base_out_dir: str | None = None) -> Path:
    d = presets_root(base_out_dir or cfg.out_dir)
    fn = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in (name or "preset")).strip("_") or "preset"
    path = d / f"{fn}.ptmgpreset.json"
    path.write_text(json.dumps(asdict(cfg), indent=2, ensure_ascii=False), encoding="utf-8")
    return path

def load_preset(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))
